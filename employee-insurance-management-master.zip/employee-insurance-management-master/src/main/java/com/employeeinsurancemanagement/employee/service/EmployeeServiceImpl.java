package com.employeeinsurancemanagement.employee.service;

import com.employeeinsurancemanagement.employee.dto.EmployeeCreateRequest;
import com.employeeinsurancemanagement.employee.dto.EmployeeUpdateRequest;
import com.employeeinsurancemanagement.employee.model.Employee;
import com.employeeinsurancemanagement.employee.model.EmployeeStatus;
import com.employeeinsurancemanagement.employee.repository.EmployeeRepository;
import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.exception.ResourceNotFoundException;
import com.employeeinsurancemanagement.organization.model.Organization;
import com.employeeinsurancemanagement.organization.repository.OrganizationRepository;
import com.employeeinsurancemanagement.security.model.User;
import com.employeeinsurancemanagement.security.repository.UserRepository;
import com.employeeinsurancemanagement.security.util.SecurityUtil;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final OrganizationRepository organizationRepository;
    private final UserRepository userRepository;
    private final org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    private User getCurrentUser() {
        String email = SecurityUtil.getCurrentUserEmail();
        assert userRepository != null;
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    /**
     * Resolves employee category based on tenure.
     * If tenure >= 5 years, employee is SENIOR, otherwise JUNIOR.
     * This is computed dynamically, not stored permanently.
     */
    private Employee.EmployeeCategory resolveCategory(Employee employee) {
        if (employee.getJoiningDate() == null) {
            return Employee.EmployeeCategory.JUNIOR;
        }
        int years = Period.between(employee.getJoiningDate(), LocalDate.now()).getYears();
        return years >= 5 ? Employee.EmployeeCategory.SENIOR : Employee.EmployeeCategory.JUNIOR;
    }

    /**
     * Applies dynamic category resolution to an employee.
     * Call this before returning any employee to ensure correct category.
     */
    private Employee applyDynamicCategory(Employee employee) {
        employee.setEmployeeCategory(resolveCategory(employee));
        return employee;
    }

    @Override
    public Employee getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(Objects.requireNonNull(id))
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found!"));
        return applyDynamicCategory(employee);
    }

    @Override
    public List<Employee> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        // Apply dynamic category to all employees
        employees.forEach(this::applyDynamicCategory);
        return employees;
    }

    @Override
    public Employee registerEmployee(EmployeeCreateRequest dto, Long organizationId) {

        User currentUser = getCurrentUser();
        if (currentUser.getRole() != User.Role.HR) {
            throw new BusinessException("Only HR allowed");
        }

        // Domain Validation
        String hrDomain = currentUser.getEmail().substring(currentUser.getEmail().indexOf("@") + 1);
        String employeeDomain = dto.getEmail().substring(dto.getEmail().indexOf("@") + 1);

        if (!hrDomain.equalsIgnoreCase(employeeDomain)) {
            throw new BusinessException("Domain mismatch: Employee email must be in @" + hrDomain);
        }

        if (employeeRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new BusinessException("User with email " + dto.getEmail() + " already exists");
        }

        // Global Phone Number Uniqueness Check
        if (employeeRepository.existsByPhoneNumber(Long.valueOf(dto.getPhoneNumber()))) {
            throw new BusinessException(
                    "Employee with phone number " + dto.getPhoneNumber() + " already exists in the system.");
        }

        // Age validation: Check if age is within valid range (18-70)
        // Redundant with DTO but good for defensive programming
        if (dto.getDateOfBirth() != null) {
            int age = Period.between(dto.getDateOfBirth(), LocalDate.now()).getYears();
            if (age < 18 || age > 70) {
                throw new BusinessException("Employee must be between 18 and 70 years old");
            }
        }

        // Joining Date Validation
        if (dto.getJoiningDate() != null) {
            // 1. Minimum Year Check (Sanity Check)
            if (dto.getJoiningDate().getYear() < 1990) {
                throw new BusinessException("Joining date cannot be before 1990");
            }

            // 2. Joining vs DOB Check (Must be at least 18 when joining)
            if (dto.getDateOfBirth() != null) {
                LocalDate minJoiningDate = dto.getDateOfBirth().plusYears(18);
                if (dto.getJoiningDate().isBefore(minJoiningDate)) {
                    throw new BusinessException(
                            "Employee cannot join before turning 18. Earliest valid joining date: " + minJoiningDate);
                }
            }
        }

        Organization org = organizationRepository.findById(organizationId)
                .orElseThrow(() -> new ResourceNotFoundException("Organization not found"));

        Employee employee = new Employee();
        employee.setEmployeeName(dto.getEmployeeName());
        employee.setEmail(dto.getEmail());
        employee.setPhoneNumber(Long.valueOf(dto.getPhoneNumber()));
        employee.setDesignation(dto.getDesignation());
        employee.setDateOfBirth(dto.getDateOfBirth());
        employee.setJoiningDate(dto.getJoiningDate());
        employee.setAddress(dto.getAddress());

        employee.setOrganization(org);
        // Set initial category based on joining date (computed dynamically)
        employee.setEmployeeCategory(resolveCategory(employee));
        employee.setStatus(EmployeeStatus.ACTIVE);

        // Create User Account
        User user = new User();
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole(User.Role.EMPLOYEE);
        user.setOrganization(org);
        user.setActive(true);
        user.setFirstLogin(true); // Force password change on first login

        user = userRepository.save(user);
        employee.setUser(user);

        for (int i = 0; i < 3; i++) {
            try {
                Long nextSeq = employeeRepository.findMaxSeqByOrganization(org) + 1;
                employee.setEmployeeSeq(nextSeq);
                return applyDynamicCategory(employeeRepository.save(employee));
            } catch (DataIntegrityViolationException e) {

            }
        }
        throw new BusinessException("Employee not registered");
    }

    @Override
    public Employee updateEmployee(Long employeeId, EmployeeUpdateRequest dto) {

        Employee existing = employeeRepository.findById(Objects.requireNonNull(employeeId))
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        // EXITED employees cannot update profile
        if (existing.getStatus() == EmployeeStatus.EXITED) {
            throw new BusinessException("Profile updates are not allowed for exited employees.");
        }

        existing.setEmployeeName(dto.getEmployeeName());

        if (dto.getPhoneNumber() != null && !dto.getPhoneNumber().isBlank()) {
            existing.setPhoneNumber(Long.valueOf(dto.getPhoneNumber()));
        }
        existing.setAddress(dto.getAddress());

        return applyDynamicCategory(employeeRepository.save(existing));
    }

    @Override
    public void deleteEmployee(Long id) {
        User currentUser = getCurrentUser();
        if (currentUser.getRole() != User.Role.HR) {
            throw new BusinessException("Only HR allowed");
        }
        if (currentUser.getRole() == User.Role.EMPLOYEE) {
            throw new BusinessException("Access denied");
        }
        try {
            employeeRepository.deleteById(id);
        } catch (Exception e) {
            throw new ResourceNotFoundException("Employee with id " + id + " not found");
        }
    }

    public void resignEmployee(Long employeeId, LocalDate resignationDate) {
        User currentUser = getCurrentUser();
        if (currentUser.getRole() != User.Role.HR) {
            throw new BusinessException("Only HR allowed");
        }
        if (currentUser.getRole() == User.Role.EMPLOYEE) {
            throw new BusinessException("Access denied");
        }
        Employee employee = employeeRepository.findById(Objects.requireNonNull(employeeId))
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        if (employee.getStatus() != EmployeeStatus.ACTIVE) {
            throw new BusinessException("Employee already resigned or exited");
        }
        employee.setResignationDate(resignationDate);
        employee.setNoticePeriodEndDate(resignationDate.plusDays(30));
        employee.setStatus(EmployeeStatus.NOTICE);

        employeeRepository.save(employee);
    }

    public void exitEmployee(Long employeeId) {
        User currentUser = getCurrentUser();
        if (currentUser.getRole() != User.Role.HR) {
            throw new BusinessException("Only HR allowed");
        }
        if (currentUser.getRole() == User.Role.EMPLOYEE) {
            throw new BusinessException("Access denied");
        }
        Employee employee = employeeRepository.findById(Objects.requireNonNull(employeeId))
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        if (employee.getStatus() != EmployeeStatus.NOTICE) {
            throw new BusinessException("Employee is not in notice period");
        }
        if (LocalDate.now().isBefore(employee.getNoticePeriodEndDate())) {
            throw new BusinessException("Notice period not completed");
        }

        // NOTE: User stays ACTIVE so they can still login to submit claims
        // on their enrolled policies. Employee status EXITED blocks:
        // - New enrollments (checked in EnrollmentServiceImpl)
        // - Profile updates (checked in EmployeeServiceImpl)
        employee.setStatus(EmployeeStatus.EXITED);
        employeeRepository.save(employee);
    }

    @Override
    public Employee getEmployeeByEmail(String email) {
        Employee employee = employeeRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        return applyDynamicCategory(employee);
    }

}
