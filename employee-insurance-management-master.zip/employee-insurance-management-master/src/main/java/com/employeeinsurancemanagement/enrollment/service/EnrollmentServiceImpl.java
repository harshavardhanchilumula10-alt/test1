package com.employeeinsurancemanagement.enrollment.service;

import com.employeeinsurancemanagement.claim.service.ClaimService;
import com.employeeinsurancemanagement.employee.model.Employee;
import com.employeeinsurancemanagement.employee.model.EmployeeStatus;
import com.employeeinsurancemanagement.employee.repository.EmployeeRepository;
import com.employeeinsurancemanagement.enrollment.model.Enrollment;
import com.employeeinsurancemanagement.enrollment.model.EnrollmentStatus;
import com.employeeinsurancemanagement.enrollment.repository.EnrollmentRepository;
import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.exception.ResourceNotFoundException;
import com.employeeinsurancemanagement.policy.model.Policy;
import com.employeeinsurancemanagement.enrollment.model.EnrollmentRequest;
import com.employeeinsurancemanagement.policy.repository.PolicyRepository;
import com.employeeinsurancemanagement.premium.model.PremiumInput;
import com.employeeinsurancemanagement.premium.service.PremiumCalculatorService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import com.employeeinsurancemanagement.premium.model.DependentDTO;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.time.LocalDate;
import java.time.Period;

@Service
@Transactional
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final EmployeeRepository employeeRepository;
    private final PolicyRepository policyRepository;
    private final PremiumCalculatorService premiumCalculatorService;
    private final ClaimService claimService;

    /**
     * Resolves employee category based on tenure.
     * If tenure >= 5 years, employee is SENIOR, otherwise JUNIOR.
     */
    private Employee.EmployeeCategory resolveCategory(Employee employee) {
        if (employee.getJoiningDate() == null) {
            return Employee.EmployeeCategory.JUNIOR;
        }
        int years = Period.between(employee.getJoiningDate(), LocalDate.now()).getYears();
        return years >= 5 ? Employee.EmployeeCategory.SENIOR : Employee.EmployeeCategory.JUNIOR;
    }

    /**
     * Applies dynamic category resolution to an employee.
     */
    private Employee applyDynamicCategory(Employee employee) {
        employee.setEmployeeCategory(resolveCategory(employee));
        return employee;
    }

    @Override
    public double calculatePremium(EnrollmentRequest request) {
        Employee employee = employeeRepository.findById(request.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        applyDynamicCategory(employee);

        Policy policy = policyRepository.findById(request.getPolicyId())
                .orElseThrow(() -> new ResourceNotFoundException("Policy not found"));

        return calculatePremiumInternal(employee, policy, request);
    }

    private double calculatePremiumInternal(Employee employee, Policy policy, EnrollmentRequest request) {
        PremiumInput input = new PremiumInput();

        if (employee.getDateOfBirth() == null) {
            throw new BusinessException("DOB required for enrollment");
        }

        int age = Period.between(employee.getDateOfBirth(), LocalDate.now()).getYears();
        input.setAge(age);

        int tenureYears = 0;
        if (employee.getJoiningDate() != null) {
            tenureYears = Period.between(employee.getJoiningDate(), LocalDate.now()).getYears();
        }
        input.setTenureYears(tenureYears);

        int pastClaims = claimService.getApprovedClaimsCountByEmployee(employee.getEmployeeId());
        input.setPastClaimsCount(pastClaims);

        input.setBasePremium(policy.getBasePremium() != null ? policy.getBasePremium() : 0.0);
        input.setCoverageAmount(policy.getCoverageAmount());
        input.setPolicyType(policy.getPolicyType());
        input.setCategory(employee.getEmployeeCategory());
        input.setDependents(request.getDependents());

        return premiumCalculatorService.calculatePremium(input);
    }

    @Override
    public Enrollment enroll(EnrollmentRequest request) {

        Employee employee = employeeRepository.findById(request.getEmployeeId())
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        applyDynamicCategory(employee);

        Policy policy = policyRepository.findById(request.getPolicyId())
                .orElseThrow(() -> new ResourceNotFoundException("Policy not found"));

        if (employee.getStatus() != EmployeeStatus.ACTIVE && employee.getStatus() != EmployeeStatus.NOTICE) {
            throw new BusinessException(
                    "Only active or notice period employees can enroll. Your status: " + employee.getStatus());
        }
        if (enrollmentRepository.findByEmployee(employee).size() > 2) {
            throw new BusinessException("Maximum two policies allowed per employee");
        }
        // Compare organization IDs instead of using equals()
        if (!policy.getOrganization().getOrganizationId().equals(employee.getOrganization().getOrganizationId())) {
            throw new BusinessException("Policy not available");
        }

        // Multi-category eligibility check - inclusive logic
        boolean isEligible = false;
        if (employee.getEmployeeCategory() == Employee.EmployeeCategory.JUNIOR
                && Boolean.TRUE.equals(policy.getEligibleJunior())) {
            isEligible = true;
        }
        if (employee.getEmployeeCategory() == Employee.EmployeeCategory.SENIOR
                && Boolean.TRUE.equals(policy.getEligibleSenior())) {
            isEligible = true;
        }
        if (!isEligible) {
            throw new BusinessException("You are not eligible for this policy");
        }

        double premium = calculatePremiumInternal(employee, policy, request);

        if (employee.getDateOfBirth() == null) {
            throw new BusinessException("DOB required for enrollment");
        }
        int age = Period.between(employee.getDateOfBirth(), LocalDate.now()).getYears();
        if (age < 18) {
            throw new BusinessException("Not eligible for insurance");
        }
        // 3. Dependent Validation
        List<DependentDTO> dependentDTOs = request.getDependents();

        // INDIVIDUAL policies do not allow dependents
        if (policy.getPolicyType() == com.employeeinsurancemanagement.policy.model.PolicyType.INDIVIDUAL) {
            if (dependentDTOs != null && !dependentDTOs.isEmpty()) {
                throw new BusinessException("Individual policies do not allow dependents");
            }
        }

        if (dependentDTOs != null && !dependentDTOs.isEmpty()) {
            if (dependentDTOs.size() > 8) {
                throw new BusinessException("Maximum 8 dependents allowed");
            }

            Set<String> uniqueDependents = new HashSet<>();
            for (DependentDTO dep : dependentDTOs) {
                if (dep.getDateOfBirth() == null) {
                    throw new BusinessException("Dependent DOB is required");
                }
                // Duplicate check using Name + DOB
                String key = dep.getName() + "|" + dep.getDateOfBirth();
                if (!uniqueDependents.add(key)) {
                    throw new BusinessException("Duplicate dependent detected");
                }

                // Age Gap Validation (Max 30 years difference)
                int ageGap = Math.abs(Period.between(employee.getDateOfBirth(), dep.getDateOfBirth()).getYears());
                if (ageGap > 30) {
                    throw new BusinessException("Age gap between employee and dependent " + dep.getName()
                            + " cannot exceed 30 years (Current gap: " + ageGap + " years)");
                }
            }
        }

        if (policy.getCoverageAmount() <= 0) {
            throw new BusinessException("Invalid coverage amount");
        }

        enrollmentRepository.findByEmployeeAndPolicy(employee, policy)
                .ifPresent(e -> {
                    throw new BusinessException("Employee already enrolled in this policy");
                });

        Enrollment enrollment = new Enrollment();
        enrollment.setEmployee(employee);
        enrollment.setPolicy(policy);
        enrollment.setEnrollmentDate(LocalDate.now());
        enrollment.setCoverageStartDate(LocalDate.now());
        enrollment.setCoverageEndDate(LocalDate.now().plusYears(1)); // Policy valid for 1 year
        enrollment.setEnrollmentStatus(EnrollmentStatus.ACTIVE);
        // Lock Premium
        enrollment.setPremiumAmount(premium);

        // Persist Dependents
        if (dependentDTOs != null) {
            for (DependentDTO dto : dependentDTOs) {
                com.employeeinsurancemanagement.enrollment.model.Dependent dependent = new com.employeeinsurancemanagement.enrollment.model.Dependent();
                dependent.setName(dto.getName());
                dependent.setRelation(dto.getRelation());
                dependent.setDateOfBirth(dto.getDateOfBirth());
                dependent.setEnrollment(enrollment);
                dependent.setEmployee(employee);
                enrollment.getDependents().add(dependent);
            }
        }

        return enrollmentRepository.save(enrollment);
    }

    @Override
    public Enrollment cancel(Long enrollmentId) {

        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));

        enrollment.setEnrollmentStatus(EnrollmentStatus.CANCELLED);
        return enrollmentRepository.save(enrollment);
    }

    @Override
    public Enrollment getById(Long enrollmentId) {
        return enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));
    }

    @Override
    public List<Enrollment> getByEmployee(Long employeeId) {

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        return enrollmentRepository.findByEmployee(employee);
    }

    @Override
    public List<Enrollment> getByPolicy(Long policyId) {

        Policy policy = policyRepository.findById(policyId)
                .orElseThrow(() -> new ResourceNotFoundException("Policy not found"));

        return enrollmentRepository.findByPolicy(policy);
    }
}
