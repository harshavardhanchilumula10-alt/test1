package com.employeeinsurancemanagement.enrollment.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EnrollmentFormdto {
    private Long employeeId;
    private Long policyId;
    private String nomineeName;
    private String nomineeRelationship;
    private Double estimatedPremium;

    private List<com.employeeinsurancemanagement.premium.model.DependentDTO> dependents = new java.util.ArrayList<>();
}
