package com.employeeinsurancemanagement.enrollment.controller;

import com.employeeinsurancemanagement.enrollment.model.Enrollment;
import com.employeeinsurancemanagement.enrollment.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/enrollments")
@RequiredArgsConstructor
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    private final com.employeeinsurancemanagement.policy.repository.PolicyRepository policyRepository;
    private final com.employeeinsurancemanagement.employee.repository.EmployeeRepository employeeRepository;

    @PostMapping("/process")
    public String process(
            @ModelAttribute("enrollmentForm") com.employeeinsurancemanagement.enrollment.dto.EnrollmentFormdto form,
            @RequestParam String action,
            Model model) {

        try {
            if ("addDependent".equals(action)) {
                if (form.getDependents().size() >= 8) {
                    model.addAttribute("error", "Cannot add more than 8 dependents");
                } else {
                    form.getDependents().add(new com.employeeinsurancemanagement.premium.model.DependentDTO());
                }
            } else if (action.startsWith("removeDependent")) {
                try {
                    String[] parts = action.split(":");
                    if (parts.length == 2) {
                        int index = Integer.parseInt(parts[1]);
                        if (form.getDependents() != null && index >= 0 && index < form.getDependents().size()) {
                            form.getDependents().remove(index);
                        }
                    } else {
                        model.addAttribute("error", "Invalid remove action");
                    }
                } catch (NumberFormatException nfe) {
                    model.addAttribute("error", "Invalid dependent index");
                }
            } else if ("calculatePremium".equals(action)) {
                com.employeeinsurancemanagement.enrollment.model.EnrollmentRequest request = createRequestFromForm(
                        form);
                double premium = enrollmentService.calculatePremium(request);
                form.setEstimatedPremium(premium);
            } else if ("enroll".equals(action)) {
                com.employeeinsurancemanagement.enrollment.model.EnrollmentRequest request = createRequestFromForm(
                        form);
                Enrollment enrollment = enrollmentService.enroll(request);
                model.addAttribute("enrollment", enrollment);
                return "redirect:/employee/enrollments";
            }
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
        }

        prepareFormModel(model, form);
        return "employee/enrollmentForm";
    }

    private void prepareFormModel(Model model, com.employeeinsurancemanagement.enrollment.dto.EnrollmentFormdto form) {
        com.employeeinsurancemanagement.policy.model.Policy policy = policyRepository.findById(form.getPolicyId())
                .orElseThrow(() -> new RuntimeException("Policy not found"));
        com.employeeinsurancemanagement.employee.model.Employee employee = employeeRepository
                .findById(form.getEmployeeId())
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        model.addAttribute("policy", policy);
        model.addAttribute("employee", employee);
        // contact details if needed, e.g. HR contact
    }

    private com.employeeinsurancemanagement.enrollment.model.EnrollmentRequest createRequestFromForm(
            com.employeeinsurancemanagement.enrollment.dto.EnrollmentFormdto form) {
        com.employeeinsurancemanagement.enrollment.model.EnrollmentRequest request = new com.employeeinsurancemanagement.enrollment.model.EnrollmentRequest();
        request.setEmployeeId(form.getEmployeeId());
        request.setPolicyId(form.getPolicyId());
        request.setDependents(form.getDependents());
        return request;
    }

    @PostMapping("/{enrollmentId}/cancel")
    public String cancel(@PathVariable Long enrollmentId, Model model) {
        Enrollment enrollment = enrollmentService.cancel(enrollmentId);
        model.addAttribute("enrollment", enrollment);
        return "enrollmentDetail";
    }

    @GetMapping("/{enrollmentId}")
    public String getById(@PathVariable Long enrollmentId, Model model) {
        Enrollment enrollment = enrollmentService.getById(enrollmentId);
        model.addAttribute("enrollment", enrollment);
        return "enrollmentDetail";
    }

    @GetMapping("/employee/{employeeId}")
    public String getByEmployee(@PathVariable Long employeeId, Model model) {
        List<Enrollment> enrollments = enrollmentService.getByEmployee(employeeId);
        model.addAttribute("enrollments", enrollments);
        return "enrollmentList";
    }

    @GetMapping("/policy/{policyId}")
    public String getByPolicy(@PathVariable Long policyId, Model model) {
        List<Enrollment> enrollments = enrollmentService.getByPolicy(policyId);
        model.addAttribute("enrollments", enrollments);
        return "enrollmentList";

    }

    @GetMapping("/employee/enrollments")
    public String getEmployeeEnrollments(Model model) {
        // Add attributes: model.addAttribute("enrollments", ...);
        return "employee/enrollments";
    }
}