package com.employeeinsurancemanagement.report.dto;

import lombok.Getter;

@Getter
public class EnrollmentReportDto {

    private final Long policyId;
    private final String policyName;
    private final Long enrollmentCount;

    public EnrollmentReportDto(Long policyId,
                               String policyName,
                               Long enrollmentCount) {
        this.policyId = policyId;
        this.policyName = policyName;
        this.enrollmentCount = enrollmentCount;
    }
}
