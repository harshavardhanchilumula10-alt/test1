package com.employeeinsurancemanagement.claim.model;

public enum  ClaimStatus {
    SUBMITTED,APPROVED,REJECTED
}