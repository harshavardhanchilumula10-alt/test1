package com.employeeinsurancemanagement.exception;

import lombok.Getter;
import java.time.LocalDateTime;

@Getter
public class ApiError {

    private final String message;
    private final LocalDateTime timestamp = LocalDateTime.now();

    public ApiError(String message) {
        this.message = message;
    }
}

