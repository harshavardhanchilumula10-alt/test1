package com.employeeinsurancemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeInsuranceManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeInsuranceManagementApplication.class, args);
    }
}
