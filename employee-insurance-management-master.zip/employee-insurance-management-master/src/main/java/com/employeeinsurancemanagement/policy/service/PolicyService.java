package com.employeeinsurancemanagement.policy.service;

import com.employeeinsurancemanagement.policy.model.Policy;

import java.util.List;

public interface PolicyService {

    Policy getPolicyById(Long policyId);

    List<Policy> getPoliciesByOrganization(Long organizationId);

    List<Policy> getAvailablePoliciesForEmployee(Long employeeId);

}
