package com.employeeinsurancemanagement.policy.model;

public enum PolicyType {
    INDIVIDUAL,FAMILY
}
