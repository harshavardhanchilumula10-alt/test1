package com.employeeinsurancemanagement.admin;

import com.employeeinsurancemanagement.claim.model.Claim;
import com.employeeinsurancemanagement.claim.model.ClaimStatus;
import com.employeeinsurancemanagement.claim.repository.ClaimRepository;
import com.employeeinsurancemanagement.claim.service.ClaimService;
import com.employeeinsurancemanagement.employee.repository.EmployeeRepository;
import com.employeeinsurancemanagement.organization.model.Organization;
import com.employeeinsurancemanagement.report.service.ReportService;
import com.employeeinsurancemanagement.security.model.User;
import com.employeeinsurancemanagement.security.repository.UserRepository;
import com.employeeinsurancemanagement.security.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final EmployeeRepository employeeRepository;
    private final ClaimRepository claimRepository;
    private final ClaimService claimService;
    private final ReportService reportService;
    private final UserRepository userRepository;

    private User getCurrentUser() {
        String email = SecurityUtil.getCurrentUserEmail();
        return userRepository.findByEmail(email).orElseThrow();
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();

        List<Claim> allClaims = claimRepository.findAll();
        List<Claim> pendingClaims = allClaims.stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.SUBMITTED)
                .filter(c -> c.getEmployee().getOrganization().equals(organization))
                .collect(Collectors.toList());

        List<Claim> approvedClaims = allClaims.stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.APPROVED)
                .filter(c -> c.getEmployee().getOrganization().equals(organization))
                .collect(Collectors.toList());

        List<Claim> rejectedClaims = allClaims.stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.REJECTED)
                .filter(c -> c.getEmployee().getOrganization().equals(organization))
                .collect(Collectors.toList());

        model.addAttribute("organizationName", organization.getOrganizationName());
        model.addAttribute("pendingClaimsCount", pendingClaims.size());
        model.addAttribute("approvedClaimsCount", approvedClaims.size());
        model.addAttribute("rejectedClaimsCount", rejectedClaims.size());
        model.addAttribute("totalEmployees", employeeRepository.findAll().stream()
                .filter(e -> e.getOrganization().equals(organization)).count());
        model.addAttribute("pendingClaims", pendingClaims.stream().limit(10).collect(Collectors.toList()));

        return "admin/dashboard";
    }

    @GetMapping("/claims")
    public String claims(Model model) {
        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();

        List<Claim> pendingClaims = claimRepository.findAll().stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.SUBMITTED)
                .filter(c -> c.getEmployee().getOrganization().equals(organization))
                .collect(Collectors.toList());

        List<Claim> processedClaims = claimRepository.findAll().stream()
                .filter(c -> c.getClaimStatus() != ClaimStatus.SUBMITTED)
                .filter(c -> c.getEmployee().getOrganization().equals(organization))
                .collect(Collectors.toList());

        model.addAttribute("organizationName", organization.getOrganizationName());
        model.addAttribute("pendingClaims", pendingClaims);
        model.addAttribute("processedClaims", processedClaims);

        return "admin/claims";
    }

    @PostMapping("/claims/{claimId}/approve")
    public String approveClaim(
            @PathVariable Long claimId,
            RedirectAttributes redirectAttributes) {
        try {
            claimService.approveClaim(claimId);
            redirectAttributes.addFlashAttribute("success", "Claim approved successfully. Payment will be processed.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/claims";
    }

    @PostMapping("/claims/{claimId}/reject")
    public String rejectClaim(
            @PathVariable Long claimId,
            @RequestParam String rejectionReason,
            RedirectAttributes redirectAttributes) {
        try {
            if (rejectionReason == null || rejectionReason.trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Rejection reason is mandatory");
                return "redirect:/admin/claims";
            }
            claimService.rejectClaim(claimId, rejectionReason);
            redirectAttributes.addFlashAttribute("success", "Claim rejected. Employee has been notified.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/admin/claims";
    }

    @GetMapping("/reports")
    public String reports(Model model) {
        try {
            User currentUser = getCurrentUser();
            Organization organization = currentUser.getOrganization();

            String orgName = (organization != null) ? organization.getOrganizationName() : "System Admin";

            model.addAttribute("organizationName", orgName);
            // Restrict reports to the admin's organization
            Long orgId = (organization != null) ? organization.getOrganizationId() : null;

            model.addAttribute("employeeReports", reportService.getEmployeeCountByOrganization(orgId));
            model.addAttribute("premiumReports", reportService.getPremiumCollectedByOrganization(orgId));
            model.addAttribute("claimReports", reportService.getClaimSummaryByEnrollment());

            return "admin/reports";
        } catch (Exception e) {
            e.printStackTrace(); // Log to console for debugging
            model.addAttribute("error", "Error loading reports: " + e.getMessage());
            // Fallback to dashboard or stay on empty reports page
            return "admin/dashboard"; // Redirecting to dashboard with error might be safer to show something works
        }
    }
}