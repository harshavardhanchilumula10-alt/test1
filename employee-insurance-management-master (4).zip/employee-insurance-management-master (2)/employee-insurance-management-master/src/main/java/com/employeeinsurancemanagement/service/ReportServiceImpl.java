package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.dto.PremiumReportDto;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportServiceImpl implements ReportService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public List<EmployeeReportDto> getEmployeeCountByOrganization(Long organizationId) {
        String query = """
                    SELECT new EmployeeReportDto(
                        o.organizationId,
                        o.organizationName,
                        COUNT(e)
                    )
                    FROM Organization o
                    LEFT JOIN o.employee e
                    WHERE (:orgId IS NULL OR o.organizationId = :orgId)
                    GROUP BY o.organizationId, o.organizationName
                """;
        return em.createQuery(query, EmployeeReportDto.class)
                .setParameter("orgId", organizationId)
                .getResultList();
    }


    @Override
    public List<ClaimReportDto> getClaimSummaryByEnrollment() {
        String query = """
    SELECT new com.employeeinsurancemanagement.dto.ClaimReportDto(
        e.enrollmentId,
        COUNT(c),
        COALESCE(SUM(CASE WHEN c.claimStatus = 'APPROVED' THEN CAST(c.approvedAmount AS double) ELSE 0 END), 0)
        COALESCE(SUM(CASE WHEN c.claimStatus = 'APPROVED' THEN 1 ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN c.claimStatus = 'SUBMITTED' THEN 1 ELSE 0 END), 0),
        COALESCE(SUM(CASE WHEN c.claimStatus = 'REJECTED' THEN 1 ELSE 0 END), 0)
    )
    FROM Enrollment e
    LEFT JOIN e.claims c
    GROUP BY e.enrollmentId
""";

        return em.createQuery(query, ClaimReportDto.class).getResultList();

    }
    @Override
    public List<PremiumReportDto> getPremiumCollectedByOrganization(Long organizationId) {
        String query = """
        SELECT new com.employeeinsurancemanagement.dto.PremiumReportDto(
            o.organizationId,
            o.organizationName,
            COALESCE(SUM(e.premiumAmount), 0)
        )
        FROM Organization o
        LEFT JOIN o.employee emp
        LEFT JOIN emp.enrollments e
        WHERE (:orgId IS NULL OR o.organizationId = :orgId)
        GROUP BY o.organizationId, o.organizationName
    """;

        return em.createQuery(query, PremiumReportDto.class)
                .setParameter("orgId", organizationId)
                .getResultList();
    }

    @Override
    public byte[] exportEmployeeReportExcel() {
        List<EmployeeReportDto> data = getEmployeeCountByOrganization(null);
        return new EmployeeReportExcelExporter().export(data);
    }

    @Override
    public byte[] exportEmployeeReportPdf() {
        List<EmployeeReportDto> data = getEmployeeCountByOrganization(null);
        return new EmployeeReportPdfExporter().export(data);
    }

    @Override
    public byte[] exportPremiumReportExcel(Long organizationId) {
        List<PremiumReportDto> data = getPremiumCollectedByOrganization(organizationId);
        return new PremiumReportExcelExporter().export(data);
    }

    @Override
    public byte[] exportPremiumReportPdf(Long organizationId) {
        List<PremiumReportDto> data = getPremiumCollectedByOrganization(organizationId);
        return new PremiumReportPdfExporter().export(data);
    }

    @Override
    public byte[] exportClaimReportExcel() {
        List<ClaimReportDto> data = getClaimSummaryByEnrollment();
        return new ClaimReportExcelExporter().export(data);
    }

    @Override
    public byte[] exportClaimReportPdf() {
        List<ClaimReportDto> data = getClaimSummaryByEnrollment();
        return new ClaimReportPdfExporter().export(data);
    }

}
