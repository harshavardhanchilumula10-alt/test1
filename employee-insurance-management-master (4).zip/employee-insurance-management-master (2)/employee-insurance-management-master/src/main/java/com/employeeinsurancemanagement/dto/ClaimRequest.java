package com.employeeinsurancemanagement.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ClaimRequest {

    @NotNull(message = "Enrollment ID is required")
    private Long enrollmentId;

    @NotNull(message = "Claim amount is required")
    @DecimalMin(value = "1.0", message = "Claim amount must be greater than 0")
    private Double claimAmount;

    @NotBlank(message = "Claim reason is required")
    private String claimReason;
}
