package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeCoverageReportDTO;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayOutputStream;
import java.util.List;

/**
 * PDF exporter for Employee Coverage Report.
 * Exports filtered data to PDF format.
 */
public class EmployeeCoveragePdfExporter {

    public byte[] export(List<EmployeeCoverageReportDTO> data, String filters) {
        Document document = new Document(PageSize.A4.rotate()); // Landscape for more columns
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Title
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph title = new Paragraph("Employee Coverage Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            // Filters info
            Font filterFont = new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY);
            Paragraph filterInfo = new Paragraph("Applied Filters: " + filters, filterFont);
            document.add(filterInfo);
            document.add(Chunk.NEWLINE);

            // Create table with 8 columns
            PdfPTable table = new PdfPTable(8);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Header style
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            BaseColor headerBg = new BaseColor(46, 204, 113); // Green

            // Add headers
            String[] headers = { "Code", "Name", "Email", "Designation", "Joining Date",
                    "Category", "Status", "Enrolled" };
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, headerFont));
                cell.setBackgroundColor(headerBg);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setPadding(8);
                table.addCell(cell);
            }

            // Data style
            Font dataFont = new Font(Font.FontFamily.HELVETICA, 9);

            for (EmployeeCoverageReportDTO dto : data) {
                table.addCell(new Phrase(dto.getEmployeeCode(), dataFont));
                table.addCell(new Phrase(dto.getEmployeeName(), dataFont));
                table.addCell(new Phrase(dto.getEmail(), dataFont));
                table.addCell(new Phrase(dto.getDesignation() != null ? dto.getDesignation() : "-", dataFont));
                table.addCell(
                        new Phrase(dto.getJoiningDate() != null ? dto.getJoiningDate().toString() : "N/A", dataFont));
                table.addCell(new Phrase(dto.getCategory().name(), dataFont));

                // Status with color
                PdfPCell statusCell = new PdfPCell(new Phrase(dto.getStatus().name(), dataFont));
                if ("ACTIVE".equals(dto.getStatus().name())) {
                    statusCell.setBackgroundColor(new BaseColor(200, 255, 200));
                } else if ("EXITED".equals(dto.getStatus().name())) {
                    statusCell.setBackgroundColor(new BaseColor(255, 200, 200));
                } else {
                    statusCell.setBackgroundColor(new BaseColor(255, 255, 200));
                }
                table.addCell(statusCell);

                // Enrollment with color
                PdfPCell enrollCell = new PdfPCell(
                        new Phrase(dto.isEnrolled() ? "Yes (" + dto.getActiveEnrollmentCount() + ")" : "No", dataFont));
                enrollCell.setBackgroundColor(dto.isEnrolled() ? new BaseColor(200, 220, 255) : BaseColor.WHITE);
                table.addCell(enrollCell);
            }

            document.add(table);

            // Footer with count
            document.add(Chunk.NEWLINE);
            Font footerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
            document.add(new Paragraph("Total Employees: " + data.size(), footerFont));

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
