package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class ClaimReportExcelExporter {

    public byte[] export(List<ClaimReportDto> data) {
        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Claims Summary");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Enrollment ID");
            header.createCell(1).setCellValue("Total Claims");
            header.createCell(2).setCellValue("Total Approved Amount");

            int rowIdx = 1;
            for (ClaimReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getEnrollmentId());
                row.createCell(1).setCellValue(dto.getTotalClaims());
                row.createCell(2).setCellValue(dto.getTotalApprovedAmount());
            }

            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Excel generation failed", e);
        }
    }
}
