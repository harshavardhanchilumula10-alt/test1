package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.model.Claim;
import com.employeeinsurancemanagement.model.ClaimStatus;
import com.employeeinsurancemanagement.repository.ClaimRepository;
import com.employeeinsurancemanagement.model.Employee;
import com.employeeinsurancemanagement.repository.EmployeeRepository;
import com.employeeinsurancemanagement.model.Enrollment;
import com.employeeinsurancemanagement.model.EnrollmentStatus;
import com.employeeinsurancemanagement.repository.EnrollmentRepository;
import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.exception.ResourceNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;


@Service
@Transactional
@RequiredArgsConstructor
public class ClaimServiceImpl implements ClaimService {

    private final ClaimRepository claimRepository;
    private final EmployeeRepository employeeRepository;
    private final EnrollmentRepository enrollmentRepository;

    @Override
    public Claim submitClaim(Long employeeId, Long enrollmentId, Double claimAmount, String claimReason) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));

        // if (employee.getStatus() == EmployeeStatus.EXITED) {
        // throw new BusinessException("Access denied");
        // }
        if (!enrollment.getEmployee().equals(employee)) {
            throw new BusinessException("Unauthorized claim");
        }

        // Check for existing PENDING claim (SUBMITTED only) for this enrollment/policy
        // APPROVED and REJECTED claims are closed and should NOT block new submissions
        List<ClaimStatus> pendingStatuses = List.of(ClaimStatus.SUBMITTED);
        boolean hasPendingClaim = claimRepository.existsActiveClaimForEnrollment(
                employeeId, enrollmentId, pendingStatuses);

        if (hasPendingClaim) {
            throw new BusinessException(
                    "You already have a pending claim for this policy. " +
                            "Please wait for admin approval before submitting a new claim.");
        }
        if (claimAmount <= 0) {
            throw new BusinessException("Invalid claim amount. Amount must be greater than zero.");
        }
        if (enrollment.getEnrollmentStatus() != EnrollmentStatus.ACTIVE) {
            throw new BusinessException("Inactive enrollment. You cannot submit claims for inactive enrollments.");
        }

        // Validate claim amount against remaining coverage
        double remainingCoverage = getRemainingCoverage(enrollmentId);

        if (remainingCoverage <= 0) {
            throw new BusinessException("Policy coverage exhausted. No remaining balance available for claims.");
        }

        // Check if claim amount exceeds remaining coverage (considering 80% rule)
        double maxClaimable = remainingCoverage / 0.80; // Max hospital bill that could be claimed
        if (claimAmount *0.80 > maxClaimable) {
            throw new BusinessException(
                    String.format("Claim amount (₹%.2f) exceeds maximum claimable amount (₹%.2f). " +
                            "Your remaining coverage balance is ₹%.2f.",
                            claimAmount, remainingCoverage, maxClaimable));
        }

        Claim claim = new Claim();
        claim.setEmployee(employee);
        claim.setEnrollment(enrollment);
        claim.setClaimAmount(claimAmount);
        claim.setClaimReason(claimReason);
        claim.setClaimStatus(ClaimStatus.SUBMITTED);
        claim.setClaimDate(LocalDate.now());

        return claimRepository.save(claim);
    }

    @Override
    public Claim approveClaim(Long claimId) {
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));
        Enrollment enrollment = claim.getEnrollment();

        if (claim.getClaimStatus() != ClaimStatus.SUBMITTED) {
            throw new BusinessException("Claim already processed");
        }

        double hospitalBill = claim.getClaimAmount();
        double eightyPercent = hospitalBill * 0.80;
        double remainingCoverage = enrollment.getPolicy().getCoverageAmount() - enrollment.getUsedAmount();


        if (remainingCoverage <= 0) {
            throw new BusinessException("Policy coverage exhausted");
        }


        double payableAmount = Math.min(eightyPercent, remainingCoverage);

        enrollment.setUsedAmount(enrollment.getUsedAmount() + payableAmount);
        claim.setApprovedAmount(payableAmount);
        claim.setClaimStatus(ClaimStatus.APPROVED);
        claim.setRejectionReason(null); // Clear any previous rejection reason

        claim.setUsedAmountAtApproval(enrollment.getUsedAmount());
        claim.setRemainingBalanceAtApproval(enrollment.getPolicy().getCoverageAmount() - enrollment.getUsedAmount());
        enrollmentRepository.save(enrollment);
        return claimRepository.save(claim);
    }

    @Override
    public Claim rejectClaim(Long claimId, String rejectionReason) {
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));

        if (claim.getClaimStatus() != ClaimStatus.SUBMITTED) {
            throw new BusinessException("Claim already processed");
        }

        if (rejectionReason == null || rejectionReason.trim().length() < 5) {
            throw new BusinessException("Rejection reason must be at least 5 characters");
        }

        claim.setApprovedAmount(0.0);
        claim.setClaimStatus(ClaimStatus.REJECTED);
        claim.setRejectionReason(rejectionReason);

        return claimRepository.save(claim);
    }

    @Override
    public Claim getClaimById(Long claimId) {
        return claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found"));
    }

    @Override
    public List<Claim> getClaimsByEmployee(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        return claimRepository.findByEmployee(employee);
    }

    @Override
    public int getApprovedClaimsCountByEmployee(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));
        return (int) claimRepository.findByEmployee(employee)
                .stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.APPROVED)
                .count();
    }

    @Override
    public double getTotalApprovedClaimAmount(Long enrollmentId) {
        Double total = claimRepository.sumApprovedClaimsByEnrollmentId(enrollmentId);
        return total != null ? total : 0.0;
    }

    @Override
    public double getRemainingCoverage(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found"));

        double totalCoverage = enrollment.getPolicy().getCoverageAmount();
        double usedAmount = enrollment.getUsedAmount() != null ? enrollment.getUsedAmount() : 0.0;
        return totalCoverage - usedAmount;
    }

    @Override
    public List<Claim> getAllClaims() {
        return claimRepository.findAll();
    }
}
