package com.employeeinsurancemanagement.controller;

import com.employeeinsurancemanagement.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    // Excel download endpoint
    @GetMapping("/employees/excel")
    public ResponseEntity<ByteArrayResource> employeeExcel() {
        byte[] file = reportService.exportEmployeeReportExcel();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=employee-report.xlsx")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new ByteArrayResource(file));
    }

    // PDF download endpoint
    @GetMapping("/employees/pdf")
    public ResponseEntity<ByteArrayResource> employeePdf() {
        byte[] file = reportService.exportEmployeeReportPdf();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=employee-report.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(new ByteArrayResource(file));
    }
}