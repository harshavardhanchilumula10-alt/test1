package com.employeeinsurancemanagement.dto;

import lombok.Getter;

@Getter
public class ClaimReportDto {

    private final Long enrollmentId;
    private final Long totalClaims;
    private final Double totalApprovedAmount;
    private final Long approvedCount;
    private final Long submittedCount;
    private final Long rejectedCount;

    public ClaimReportDto(Long enrollmentId,
                          Long totalClaims,
                          Double totalApprovedAmount,
                          Long approvedCount,
                          Long submittedCount,
                          Long rejectedCount) {
        this.enrollmentId = enrollmentId;
        this.totalClaims = totalClaims;
        this.totalApprovedAmount = totalApprovedAmount;
        this.approvedCount = approvedCount;
        this.submittedCount = submittedCount;
        this.rejectedCount = rejectedCount;
    }
}

