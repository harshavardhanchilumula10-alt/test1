package com.employeeinsurancemanagement.model;

import com.employeeinsurancemanagement.dto.DependentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EnrollmentRequest {
    private Long employeeId;
    private Long policyId;
    private List<DependentDTO> dependents;
}
