package com.employeeinsurancemanagement.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "organization_id", "employeeSeq" }))
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long employeeId;
    @NotBlank
    @Size(min = 3)
    @Column(nullable = false)
    private String employeeName;
    @Embedded
    private EmployeeAddress address;

    private Long phoneNumber;

    @Column(nullable = false, unique = true)
    private String email;
    @Column(nullable = false)
    private String designation;

    @Column(nullable = false, unique = true, updatable = false)
    private String employeeCode;

    @Column(nullable = false)
    private Long employeeSeq;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EmployeeCategory employeeCategory;

    @ManyToOne(optional = false)
    @JoinColumn(name = "organization_id")
    private Organization organization;

    @Column(updatable = false)
    private LocalDate dateOfBirth;

    @Column(updatable = true)
    private LocalDate joiningDate;

    @OneToOne
    @JoinColumn(name = "user_id", unique = true)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EmployeeStatus status = EmployeeStatus.ACTIVE;

    private LocalDate resignationDate;
    private LocalDate noticePeriodEndDate;

    @PrePersist
    private void generateEmployeeId() {
        if (this.employeeCode == null && this.organization != null) {
            String organizationName = (organization.getOrganizationName() != null) ? organization.getOrganizationName()
                    : "";
            String orgcode = organizationName.replaceAll("\\s+", "").toUpperCase();
            orgcode = orgcode.substring(0, Math.min(3, orgcode.length()));
            long seqVal = (employeeSeq == null) ? 0L : employeeSeq;
            String seq = String.format("%03d", seqVal);
            this.employeeCode = orgcode + seq;
        }
    }

    public enum EmployeeCategory {
        JUNIOR, SENIOR
    }
}
