package com.employeeinsurancemanagement.controller;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.employeeinsurancemanagement.dto.EmployeeReportDto;
import com.employeeinsurancemanagement.dto.PremiumReportDto;
import com.employeeinsurancemanagement.model.*;
import com.employeeinsurancemanagement.repository.ClaimRepository;
import com.employeeinsurancemanagement.dto.EmployeeCreateRequest;
import com.employeeinsurancemanagement.repository.EmployeeRepository;
import com.employeeinsurancemanagement.service.*;
import com.employeeinsurancemanagement.repository.EnrollmentRepository;
import com.employeeinsurancemanagement.dto.EnrollmentStateFilter;
import com.employeeinsurancemanagement.repository.PolicyRepository;
import com.employeeinsurancemanagement.repository.UserRepository;
import com.employeeinsurancemanagement.security.SecurityUtil;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/hr")
@RequiredArgsConstructor
public class HrController {

    private final EmployeeService employeeService;
    private final EmployeeRepository employeeRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final ClaimRepository claimRepository;
    private final PolicyRepository policyRepository;
    private final ReportService reportService;
    private final UserRepository userRepository;
    private final HrReportService hrReportService;

    private User getCurrentUser() {
        String email = SecurityUtil.getCurrentUserEmail();
        return userRepository.findByEmail(email).orElseThrow();
    }

    private Map<String, String> getAdminContact() {
        User admin = userRepository.findAll().stream()
                .filter(u -> u.getRole() == User.Role.ADMIN)
                .findFirst()
                .orElse(null);

        Map<String, String> contact = new HashMap<>();
        if (admin != null) {
            contact.put("name", "Admin");
            contact.put("email", admin.getEmail());
        }
        return contact;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User currentUser = getCurrentUser();
        Long orgId = currentUser.getOrganization().getOrganizationId();

        List<Employee> allEmployees = employeeRepository.findAll().stream()
                .filter(e -> e.getOrganization().getOrganizationId().equals(orgId))
                .collect(Collectors.toList());

        long activeEmployees = allEmployees.stream()
                .filter(e -> e.getStatus() == EmployeeStatus.ACTIVE).count();
        long noticeEmployees = allEmployees.stream()
                .filter(e -> e.getStatus() == EmployeeStatus.NOTICE).count();
        long exitedEmployees = allEmployees.stream()
                .filter(e -> e.getStatus() == EmployeeStatus.EXITED).count();

        List<Claim> pendingClaims = claimRepository.findAll().stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.SUBMITTED)
                .filter(c -> c.getEmployee().getOrganization().getOrganizationId().equals(orgId))
                .collect(Collectors.toList()); // for the top card

        // Count enrollments for THIS organization only
        long totalEnrollments = enrollmentRepository.findAll().stream()
                .filter(e -> e.getEmployee().getOrganization().getOrganizationId().equals(orgId))
                .count();

        model.addAttribute("currentHR", currentUser);
        model.addAttribute("organizationName", currentUser.getOrganization().getOrganizationName());
        model.addAttribute("totalEmployees", allEmployees.size());
        model.addAttribute("activeEmployees", activeEmployees);
        model.addAttribute("noticeEmployees", noticeEmployees);
        model.addAttribute("exitedEmployees", exitedEmployees);
        model.addAttribute("totalEnrollments", totalEnrollments);
        model.addAttribute("pendingClaimsCount", pendingClaims.size());
        model.addAttribute("recentEmployees", allEmployees.stream().limit(5).collect(Collectors.toList()));
        model.addAttribute("adminContact", getAdminContact());
        model.addAttribute("recentPendingClaims", pendingClaims.stream().limit(5).collect(Collectors.toList()));

        return "hr/dashboard";
    }

    @GetMapping("/employees")
    public String employees(Model model) {
        User currentUser = getCurrentUser();
        Long orgId = currentUser.getOrganization().getOrganizationId();

        List<Employee> employees = employeeRepository.findAll().stream()
                .filter(e -> e.getOrganization().getOrganizationId().equals(orgId))
                .collect(Collectors.toList());

        model.addAttribute("employees", employees);
        model.addAttribute("organizationId", orgId);
        model.addAttribute("organizationName", currentUser.getOrganization().getOrganizationName());
        model.addAttribute("adminContact", getAdminContact());

        return "hr/employees";
    }

    @GetMapping("/create-employee")
    public String createEmployeeForm(Model model) {
        User currentUser = getCurrentUser();
        model.addAttribute("employeeCreateRequest", new EmployeeCreateRequest());
        model.addAttribute("organizationId", currentUser.getOrganization().getOrganizationId());
        model.addAttribute("organizationName", currentUser.getOrganization().getOrganizationName());
        model.addAttribute("adminContact", getAdminContact());
        return "hr/create-employee";
    }

    @PostMapping("/create-employee")
    public String createEmployee(
            @Valid @ModelAttribute EmployeeCreateRequest employeeCreateRequest,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        User currentUser = getCurrentUser();

        if (bindingResult.hasErrors()) {
            model.addAttribute("error", "Validation failed. Please check the fields below.");
            model.addAttribute("organizationId", currentUser.getOrganization().getOrganizationId());
            model.addAttribute("adminContact", getAdminContact());
            return "hr/create-employee";
        }

        try {
            employeeService.registerEmployee(employeeCreateRequest, currentUser.getOrganization().getOrganizationId());
            redirectAttributes.addFlashAttribute("success", "Employee registered successfully.");
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("organizationId", currentUser.getOrganization().getOrganizationId());
            model.addAttribute("adminContact", getAdminContact());
            return "hr/create-employee";
        }

        return "redirect:/hr/employees";
    }

    @PostMapping("/employees/{employeeId}/resign")
    public String resignEmployee(
            @PathVariable Long employeeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate resignationDate,
            RedirectAttributes redirectAttributes) {
        try {
            employeeService.resignEmployee(employeeId, resignationDate);
            redirectAttributes.addFlashAttribute("success", "Employee moved to notice period successfully.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/hr/employees";
    }

    @PostMapping("/employees/{employeeId}/exit")
    public String exitEmployee(
            @PathVariable Long employeeId,
            RedirectAttributes redirectAttributes) {
        try {
            employeeService.exitEmployee(employeeId);
            redirectAttributes.addFlashAttribute("success", "Employee exited successfully. Exit benefits calculated.");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/hr/employees";
    }

    @GetMapping("/enrollments")
    public String enrollments(Model model) {
        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();
        Long orgId = organization.getOrganizationId();

        List<Enrollment> enrollments = enrollmentRepository.findAll()
                .stream()
                .filter(e -> e.getEmployee().getOrganization().getOrganizationId().equals(orgId))
                .collect(Collectors.toList());
        model.addAttribute("enrollments", enrollments);
        model.addAttribute("organizationName", currentUser.getOrganization().getOrganizationName());
        model.addAttribute("adminContact", getAdminContact());

        return "hr/enrollments";
    }

    @GetMapping("/claims")
    public String claims(Model model) {
        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();
        Long orgId = organization.getOrganizationId();

        List<Claim> allClaims = claimRepository.findAll().stream()
                .filter(c -> c.getEmployee().getOrganization().getOrganizationId().equals(orgId))
                .sorted(Comparator.comparing((Claim c) -> c.getClaimStatus() == ClaimStatus.SUBMITTED ? 0 : 1) // SUBMITTED
                                                                                                               // first
                        .thenComparing(Claim::getClaimDate, Comparator.reverseOrder()))// newest first
                .collect(Collectors.toList());

        List<Claim> pendingClaims = allClaims.stream()
                .filter(c -> c.getClaimStatus() == ClaimStatus.SUBMITTED)
                .collect(Collectors.toList());

        model.addAttribute("allClaims", allClaims);
        model.addAttribute("pendingClaims", pendingClaims);
        model.addAttribute("organizationName", organization.getOrganizationName());
        model.addAttribute("adminContact", getAdminContact());
        return "hr/claims";
    }

    @GetMapping("/reports")
    public String reports(@RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String status,
            Model model) {
        try {
            User currentUser = getCurrentUser();

            model.addAttribute("currentHR", currentUser);
            model.addAttribute("organizationName", currentUser.getOrganization().getOrganizationName());

            System.out.println("Fetching employee reports...");
            model.addAttribute("employeeReports",
                    reportService.getEmployeeCountByOrganization(currentUser.getOrganization().getOrganizationId()));

            System.out.println("Fetching premium reports...");
            model.addAttribute("premiumReports",
                    reportService.getPremiumCollectedByOrganization(currentUser.getOrganization().getOrganizationId()));

            System.out.println("Fetching claim reports...");
            // Pass status filter
            List<ClaimReportDto> claimReports = reportService.getClaimSummaryByEnrollment(status);

            // Sorting Logic
            if ("dateDesc".equalsIgnoreCase(sortBy) || sortBy == null) { // Default
                claimReports.sort(Comparator.comparing(ClaimReportDto::getClaimDate,
                        Comparator.nullsLast(Comparator.reverseOrder())));
            } else if ("dateAsc".equalsIgnoreCase(sortBy)) {
                claimReports.sort(Comparator.comparing(ClaimReportDto::getClaimDate,
                        Comparator.nullsLast(Comparator.naturalOrder())));
            } else if ("status".equalsIgnoreCase(sortBy)) {
                claimReports.sort(Comparator.comparing(ClaimReportDto::getClaimStatus));
            }

            model.addAttribute("claimReports", claimReports);
            model.addAttribute("selectedSortBy", sortBy);
            model.addAttribute("selectedStatus", status);

            model.addAttribute("adminContact", getAdminContact());
            System.out.println("Reports loaded successfully.");

            return "hr/reports";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Failed to load reports: " + e.getMessage());
            return "redirect:/hr/dashboard";
        }
    }

    // ... policies method ...

    // ... employees-report methods ...

    // ... exportExcel/PDF methods ...

    @GetMapping("/reports/claims/export/excel")
    public void exportClaimsReportExcel(@RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String status,
            HttpServletResponse response) throws IOException {
        List<ClaimReportDto> data = reportService.getClaimSummaryByEnrollment(status);
        if ("dateDesc".equalsIgnoreCase(sortBy) || sortBy == null) {
            data.sort(Comparator.comparing(ClaimReportDto::getClaimDate,
                    Comparator.nullsLast(Comparator.reverseOrder())));
        } else if ("dateAsc".equalsIgnoreCase(sortBy)) {
            data.sort(Comparator.comparing(ClaimReportDto::getClaimDate,
                    Comparator.nullsLast(Comparator.naturalOrder())));
        } else if ("status".equalsIgnoreCase(sortBy)) {
            data.sort(Comparator.comparing(ClaimReportDto::getClaimStatus));
        }

        ClaimReportExcelExporter exporter = new ClaimReportExcelExporter();
        byte[] excelBytes = exporter.export(data);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=claims-report.xlsx");
        response.getOutputStream().write(excelBytes);
        response.getOutputStream().flush();
    }

    @GetMapping("/reports/claims/export/pdf")
    public void exportClaimsReportPdf(@RequestParam(required = false) String sortBy,
            @RequestParam(required = false) String status,
            HttpServletResponse response) throws IOException {
        List<ClaimReportDto> data = reportService.getClaimSummaryByEnrollment(status);
        if ("dateDesc".equalsIgnoreCase(sortBy) || sortBy == null) {
            data.sort(Comparator.comparing(ClaimReportDto::getClaimDate,
                    Comparator.nullsLast(Comparator.reverseOrder())));
        } else if ("dateAsc".equalsIgnoreCase(sortBy)) {
            data.sort(Comparator.comparing(ClaimReportDto::getClaimDate,
                    Comparator.nullsLast(Comparator.naturalOrder())));
        } else if ("status".equalsIgnoreCase(sortBy)) {
            data.sort(Comparator.comparing(ClaimReportDto::getClaimStatus));
        }

        ClaimReportPdfExporter exporter = new ClaimReportPdfExporter();
        byte[] pdfBytes = exporter.export(data);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=claims-report.pdf");
        response.getOutputStream().write(pdfBytes);
        response.getOutputStream().flush();
    }

    @GetMapping("/policies")
    public String policies(Model model) {
        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();
        Long orgId = organization.getOrganizationId();

        // Get ALL policies for this organization from PolicyRepository
        List<Policy> allOrgPolicies = policyRepository.findByOrganization(organization);

        // Count active enrollments per policy - filter by organization ID
        Map<Long, Long> enrollmentCountByPolicy = enrollmentRepository.findAll().stream()
                .filter(e -> e.getPolicy().getOrganization().getOrganizationId().equals(orgId))
                .filter(e -> e
                        .getEnrollmentStatus() == EnrollmentStatus.ACTIVE)
                .collect(Collectors.groupingBy(
                        e -> e.getPolicy().getPolicyId(),
                        Collectors.counting()));

        // Calculate total enrollments (sum of all enrollment counts)
        long totalEnrollments = enrollmentCountByPolicy.values().stream().mapToLong(v -> v).sum();

        model.addAttribute("policies", allOrgPolicies);
        model.addAttribute("enrollmentCounts", enrollmentCountByPolicy);
        model.addAttribute("totalEnrollments", totalEnrollments);
        model.addAttribute("organizationName", organization.getOrganizationName());
        model.addAttribute("adminContact", getAdminContact());

        return "hr/policies";
    }

    /**
     * HR Employee Coverage Report with filtering, sorting, and pagination.
     * Controller stays thin - all logic is in HrReportService.
     */
    @GetMapping("/employees-report")
    public String employeesReport(
            @RequestParam(defaultValue = "ALL") String status,
            @RequestParam(defaultValue = "ALL") String category,
            @RequestParam(defaultValue = "ALL") String enrollmentState,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "0") int page,
            Model model) {

        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();

        // Parse enrollment state filter
        EnrollmentStateFilter enrollmentFilter;
        try {
            enrollmentFilter = EnrollmentStateFilter.valueOf(enrollmentState.toUpperCase());
        } catch (IllegalArgumentException e) {
            enrollmentFilter = EnrollmentStateFilter.ALL;
        }

        // Validate page size (must be between 1 and 300)
        if (pageSize < 1 || pageSize > 300) {
            pageSize = 10; // default fallback
        }
        List<Employee> employees = employeeRepository
                .findByOrganizationOrganizationId(organization.getOrganizationId());
        int totalEmployees = employees.size();

        // Validate page size (must be between 1 and totalEmployees, capped at 300)
        if (pageSize < 1) {
            pageSize = 10; // fallback
        } else if (pageSize > totalEmployees) {
            pageSize = totalEmployees; // cap at employee count
        }

        // Optional: still enforce an absolute max of 300
        if (pageSize > 300) {
            pageSize = 300;
        }

        // Get report from service (all logic is there)
        HrReportService.EmployeeCoverageReportResult result = hrReportService.getEmployeeCoverageReport(
                organization.getOrganizationId(),
                status,
                category,
                enrollmentFilter,
                sortBy,
                sortDir,
                page,
                pageSize);

        // Pass data to view
        model.addAttribute("employees", result.content());
        model.addAttribute("currentPage", result.currentPage());
        model.addAttribute("pageSize", result.pageSize());
        model.addAttribute("totalElements", result.totalElements());
        model.addAttribute("totalPages", result.totalPages());
        model.addAttribute("hasNext", result.hasNext());
        model.addAttribute("hasPrevious", result.hasPrevious());

        // Pass current filter values back to view for form state
        model.addAttribute("selectedStatus", status);
        model.addAttribute("selectedCategory", category);
        model.addAttribute("selectedEnrollmentState", enrollmentState);
        model.addAttribute("selectedSortBy", sortBy);
        model.addAttribute("selectedSortDir", sortDir);

        model.addAttribute("organizationName", organization.getOrganizationName());

        return "hr/employees-report";
    }

    /**
     * Export filtered employee report to Excel.
     * Exports ALL matching records (not just current page).
     */
    @GetMapping("/employees-report/export/excel")
    public void exportEmployeesReportExcel(
            @RequestParam(defaultValue = "ALL") String status,
            @RequestParam(defaultValue = "ALL") String category,
            @RequestParam(defaultValue = "ALL") String enrollmentState,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            HttpServletResponse response) throws IOException {

        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();

        // Parse enrollment state filter
        EnrollmentStateFilter enrollmentFilter;
        try {
            enrollmentFilter = EnrollmentStateFilter.valueOf(enrollmentState.toUpperCase());
        } catch (IllegalArgumentException e) {
            enrollmentFilter = EnrollmentStateFilter.ALL;
        }

        // Get ALL filtered data (large page size to get all)
        HrReportService.EmployeeCoverageReportResult result = hrReportService.getEmployeeCoverageReport(
                organization.getOrganizationId(),
                status,
                category,
                enrollmentFilter,
                sortBy,
                sortDir,
                0,
                10000 // Get all records
        );

        // Build filter description for export header
        String filters = buildFilterDescription(status, category, enrollmentState, sortBy, sortDir);

        // Generate Excel
        EmployeeCoverageExcelExporter exporter = new EmployeeCoverageExcelExporter();
        byte[] excelBytes = exporter.export(result.content(), filters);

        // Set response headers
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=employee-coverage-report.xlsx");
        response.getOutputStream().write(excelBytes);
        response.getOutputStream().flush();
    }

    /**
     * Export filtered employee report to PDF.
     * Exports ALL matching records (not just current page).
     */
    @GetMapping("/employees-report/export/pdf")
    public void exportEmployeesReportPdf(
            @RequestParam(defaultValue = "ALL") String status,
            @RequestParam(defaultValue = "ALL") String category,
            @RequestParam(defaultValue = "ALL") String enrollmentState,
            @RequestParam(defaultValue = "name") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir,
            HttpServletResponse response) throws IOException {

        User currentUser = getCurrentUser();
        Organization organization = currentUser.getOrganization();

        // Parse enrollment state filter
        EnrollmentStateFilter enrollmentFilter;
        try {
            enrollmentFilter = EnrollmentStateFilter.valueOf(enrollmentState.toUpperCase());
        } catch (IllegalArgumentException e) {
            enrollmentFilter = EnrollmentStateFilter.ALL;
        }

        // Get ALL filtered data
        HrReportService.EmployeeCoverageReportResult result = hrReportService.getEmployeeCoverageReport(
                organization.getOrganizationId(),
                status,
                category,
                enrollmentFilter,
                sortBy,
                sortDir,
                0,
                10000 // Get all records
        );

        // Build filter description for export header
        String filters = buildFilterDescription(status, category, enrollmentState, sortBy, sortDir);

        // Generate PDF
        EmployeeCoveragePdfExporter exporter = new EmployeeCoveragePdfExporter();
        byte[] pdfBytes = exporter.export(result.content(), filters);

        // Set response headers
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=employee-coverage-report.pdf");
        response.getOutputStream().write(pdfBytes);
        response.getOutputStream().flush();
    }

    /**
     * Build a human-readable filter description for export headers.
     */
    private String buildFilterDescription(String status, String category, String enrollmentState,
            String sortBy, String sortDir) {
        StringBuilder sb = new StringBuilder();
        if (!"ALL".equalsIgnoreCase(status)) {
            sb.append("Status: ").append(status).append(" | ");
        }
        if (!"ALL".equalsIgnoreCase(category)) {
            sb.append("Category: ").append(category).append(" | ");
        }
        if (!"ALL".equalsIgnoreCase(enrollmentState)) {
            sb.append("Enrollment: ").append(enrollmentState.replace("_", " ")).append(" | ");
        }
        sb.append("Sorted by: ").append(sortBy).append(" (").append(sortDir.toUpperCase()).append(")");
        return sb.toString();
    }

    @GetMapping("/reports/employees/excel")
    public void exportEmployeesReportExcel(HttpServletResponse response) throws IOException {
        User currentUser = getCurrentUser();
        Long orgId = currentUser.getOrganization().getOrganizationId();

        List<EmployeeReportDto> data = reportService.getEmployeeCountByOrganization(orgId);

        EmployeeReportExcelExporter exporter = new EmployeeReportExcelExporter();
        byte[] excelBytes = exporter.export(data);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=employee-report.xlsx");
        response.getOutputStream().write(excelBytes);
        response.getOutputStream().flush();
    }

    @GetMapping("/reports/employees/pdf")
    public void exportEmployeesReportPdf(HttpServletResponse response) throws IOException {
        User currentUser = getCurrentUser();
        Long orgId = currentUser.getOrganization().getOrganizationId();

        List<EmployeeReportDto> data = reportService.getEmployeeCountByOrganization(orgId);

        EmployeeReportPdfExporter exporter = new EmployeeReportPdfExporter();
        byte[] pdfBytes = exporter.export(data);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=employee-report.pdf");
        response.getOutputStream().write(pdfBytes);
        response.getOutputStream().flush();
    }

    @GetMapping("/reports/premium/export/excel")
    public void exportPremiumReportExcel(HttpServletResponse response) throws IOException {
        User currentUser = getCurrentUser();
        Long orgId = currentUser.getOrganization().getOrganizationId();

        List<PremiumReportDto> data = reportService.getPremiumCollectedByOrganization(orgId);

        PremiumReportExcelExporter exporter = new PremiumReportExcelExporter();
        byte[] excelBytes = exporter.export(data);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=premium-report.xlsx");
        response.getOutputStream().write(excelBytes);
        response.getOutputStream().flush();
    }

    @GetMapping("/reports/premium/export/pdf")
    public void exportPremiumReportPdf(HttpServletResponse response) throws IOException {
        User currentUser = getCurrentUser();
        Long orgId = currentUser.getOrganization().getOrganizationId();

        List<PremiumReportDto> data = reportService.getPremiumCollectedByOrganization(orgId);

        PremiumReportPdfExporter exporter = new PremiumReportPdfExporter();
        byte[] pdfBytes = exporter.export(data);

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=premium-report.pdf");
        response.getOutputStream().write(pdfBytes);
        response.getOutputStream().flush();
    }

}
