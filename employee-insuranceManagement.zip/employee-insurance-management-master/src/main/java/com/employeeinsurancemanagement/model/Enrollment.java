package com.employeeinsurancemanagement.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@Table(uniqueConstraints = {
        @UniqueConstraint(columnNames = { "employee_id", "policy_id" })
})
public class Enrollment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long enrollmentId;

    private LocalDate enrollmentDate;
    private LocalDate coverageStartDate;
    private LocalDate coverageEndDate;

    @ManyToOne(optional = false)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @ManyToOne(optional = false)
    @JoinColumn(name = "policy_id", nullable = false)
    private Policy policy;

    @Enumerated(EnumType.STRING)
    private EnrollmentStatus enrollmentStatus;

    @Column(nullable = false)
    private Double premiumAmount;

    @Column(nullable = false)
    private Double usedAmount = 0.0;

    @OneToMany(mappedBy = "enrollment", cascade = CascadeType.ALL)
    private java.util.List<Dependent> dependents = new java.util.ArrayList<>();

    @OneToMany(mappedBy = "enrollment")
    private java.util.List<Claim> claims = new java.util.ArrayList<>();

}
