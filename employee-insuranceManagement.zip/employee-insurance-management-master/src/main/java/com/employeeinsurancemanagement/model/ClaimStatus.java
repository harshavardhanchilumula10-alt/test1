package com.employeeinsurancemanagement.model;

public enum  ClaimStatus {
    SUBMITTED,APPROVED,REJECTED
}