package com.employeeinsurancemanagement.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
public class Organization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long organizationId;
    @Column(unique = true, nullable = false)
    private String organizationName;
    @Column(unique = true, updatable = false, nullable = false)
    private String orgCode;

    @OneToMany(mappedBy = "organization")
    private List<Employee> employee;

    @PrePersist
    private void generateOrgCode() {
        if (this.orgCode == null || this.orgCode.isBlank()) {
            String name = (this.organizationName != null) ? this.organizationName : "";
            String letters = name.replaceAll("[^A-Za-z]", "");
            if (letters.isEmpty()) {
                this.orgCode = "ORG";
            } else {
                this.orgCode = letters.substring(0, Math.min(3, letters.length())).toUpperCase();
            }
        }
    }

    // cognizant -> COG
}
