package com.employeeinsurancemanagement.model;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Embedded address for Employee.
 * Validations applied for employee self-service profile updates.
 */
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmployeeAddress {

    @NotBlank(message = "City is required")
    private String city;

    @NotBlank(message = "Country is required")
    private String country;

    @NotBlank(message = "State is required")
    private String state;

    @NotBlank(message = "Zipcode is required")
    @Pattern(regexp = "^[0-9]{5,6}$", message = "Zipcode must be 5-6 digits")
    private String zipcode;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (city != null && !city.isEmpty())
            sb.append(city);
        if (state != null && !state.isEmpty()) {
            if (sb.length() > 0)
                sb.append(", ");
            sb.append(state);
        }
        if (country != null && !country.isEmpty()) {
            if (sb.length() > 0)
                sb.append(", ");
            sb.append(country);
        }
        if (zipcode != null && !zipcode.isEmpty()) {
            if (sb.length() > 0)
                sb.append(" - ");
            sb.append(zipcode);
        }
        return sb.length() > 0 ? sb.toString() : "Not provided";
    }
}
