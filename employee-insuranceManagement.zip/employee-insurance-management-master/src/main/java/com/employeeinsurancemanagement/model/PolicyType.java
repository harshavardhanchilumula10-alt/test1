package com.employeeinsurancemanagement.model;

public enum PolicyType {
    INDIVIDUAL,FAMILY
}
