package com.employeeinsurancemanagement.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Getter
@Setter
public class Claim {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long claimId;

    private Double claimAmount;

    @Enumerated(EnumType.STRING)
    private ClaimStatus claimStatus;

    private String claimReason;

    private LocalDate claimDate;

    @ManyToOne(optional = false)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    private Double approvedAmount;

    @ManyToOne(optional = false)
    @JoinColumn(name = "enrollment_id")
    private Enrollment enrollment;

    // New field for rejection reason
    @Column(columnDefinition = "TEXT")
    private String rejectionReason;

    private Double remainingBalanceAtApproval;
    private Double usedAmountAtApproval;
}