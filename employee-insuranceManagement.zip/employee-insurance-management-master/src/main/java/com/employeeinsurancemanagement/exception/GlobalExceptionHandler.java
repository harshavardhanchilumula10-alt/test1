package com.employeeinsurancemanagement.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Global exception handler for MVC controllers.
 * Catches application-level exceptions (BusinessException,
 * ResourceNotFoundException)
 * and redirects with flash attributes for UI display.
 * 
 * Note: HTTP-level errors (404, 403, 500) are handled by ErrorPageController.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handles BusinessException - validation/business rule violations.
     * Redirects back to the referer page with the error message.
     */
    @ExceptionHandler(BusinessException.class)
    public String handleBusinessException(BusinessException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", ex.getMessage());

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles ResourceNotFoundException - when a requested resource is not found.
     * Redirects to dashboard with error message.
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public String handleResourceNotFound(ResourceNotFoundException ex,
            RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("error", ex.getMessage());
        return "redirect:/dashboard";
    }

    /**
     * Fallback handler for any other uncaught exceptions.
     * Shows a generic error message to avoid exposing internal details.
     */
    @ExceptionHandler(Exception.class)
    public String handleGenericException(Exception ex,
            RedirectAttributes redirectAttributes) {
        // Log the exception for debugging (optional: add proper logging)
        ex.printStackTrace();
        redirectAttributes.addFlashAttribute("error", "An unexpected error occurred. Please try again.");
        return "redirect:/dashboard";
    }
}
