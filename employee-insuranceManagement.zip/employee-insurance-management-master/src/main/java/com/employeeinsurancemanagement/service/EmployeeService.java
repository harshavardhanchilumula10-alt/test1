package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.EmployeeCreateRequest;
import com.employeeinsurancemanagement.dto.EmployeeUpdateRequest;
import com.employeeinsurancemanagement.model.Employee;

import java.time.LocalDate;
import java.util.List;


public interface EmployeeService {

    Employee getEmployeeById(Long id);
    List<Employee> getAllEmployees();
    Employee registerEmployee(EmployeeCreateRequest employee, Long organizationId);
    Employee updateEmployee(Long employeeId,EmployeeUpdateRequest employee);
    void deleteEmployee(Long id);
    void resignEmployee(Long employeeId, LocalDate resignationDate);
    void exitEmployee(Long employeeId);
    Employee getEmployeeByEmail(String email);
}
