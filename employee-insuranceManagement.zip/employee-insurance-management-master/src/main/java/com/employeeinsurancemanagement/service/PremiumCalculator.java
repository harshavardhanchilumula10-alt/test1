package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.model.PremiumInput;

public interface PremiumCalculator {

    double calculatePremium(PremiumInput input);
}
