package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.PremiumReportDto;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class PremiumReportPdfExporter {

    public byte[] export(List<PremiumReportDto> data) {
        Document document = new Document(PageSize.A4);
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Title
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph title = new Paragraph("Premium Collected by Organization", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(3);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            BaseColor headerBg = new BaseColor(241, 196, 15); // Yellow

            String[] headers = { "Organization ID", "Organization Name", "Total Premium Collected" };
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, headerFont));
                cell.setBackgroundColor(headerBg);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setPadding(8);
                table.addCell(cell);
            }

            Font dataFont = new Font(Font.FontFamily.HELVETICA, 9);

            for (PremiumReportDto dto : data) {
                table.addCell(new Phrase(String.valueOf(dto.getOrganizationId()), dataFont));
                table.addCell(new Phrase(dto.getOrganizationName(), dataFont));
                table.addCell(new Phrase("₹" + String.format("%.2f", dto.getTotalPremiumCollected()), dataFont));
            }

            document.add(table);

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
