package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.ClaimReportDto;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class ClaimReportPdfExporter {

    public byte[] export(List<ClaimReportDto> data) {
        Document document = new Document(PageSize.A4.rotate());
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            // Title
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph title = new Paragraph("Claims Summary by Enrollment", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Header style
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            BaseColor headerBg = new BaseColor(52, 152, 219); // Blue

            String[] headers = { "Enrollment ID", "Claim ID", "Approved Amount", "Claim Date", "Status" };
            for (String h : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(h, headerFont));
                cell.setBackgroundColor(headerBg);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setPadding(8);
                table.addCell(cell);
            }

            Font dataFont = new Font(Font.FontFamily.HELVETICA, 9);

            for (ClaimReportDto dto : data) {
                table.addCell(new Phrase("#" + dto.getEnrollmentId(), dataFont));
                table.addCell(new Phrase(dto.getClaimId() != null ? String.valueOf(dto.getClaimId()) : "-", dataFont));

                Double amt = dto.getApprovedAmount();
                table.addCell(new Phrase("₹" + String.format("%.2f", amt != null ? amt : 0.0), dataFont));

                if (dto.getClaimDate() != null) {
                    table.addCell(new Phrase(dto.getClaimDate().toString(), dataFont));
                } else {
                    table.addCell(new Phrase("-", dataFont));
                }

                table.addCell(new Phrase(dto.getClaimStatus(), dataFont));
            }

            document.add(table);

            document.close();
        } catch (Exception e) {
            throw new RuntimeException("PDF generation failed", e);
        }

        return out.toByteArray();
    }
}
