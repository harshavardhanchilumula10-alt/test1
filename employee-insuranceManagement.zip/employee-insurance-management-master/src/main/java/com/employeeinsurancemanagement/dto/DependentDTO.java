package com.employeeinsurancemanagement.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DependentDTO {
    private String name;
    private String relation; // SPOUSE, CHILD, PARENT
    private int age;
    @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
    private java.time.LocalDate dateOfBirth;

    public DependentDTO() {
    }

    public DependentDTO(String name, String relation, java.time.LocalDate dateOfBirth) {
        this.name = name;
        this.relation = relation;
        this.dateOfBirth = dateOfBirth;
        if (dateOfBirth != null) {
            this.age = java.time.Period.between(dateOfBirth, java.time.LocalDate.now()).getYears();
        }

    }

    public void setDateOfBirth(java.time.LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        if (dateOfBirth != null) {
            this.age = java.time.Period.between(dateOfBirth, java.time.LocalDate.now()).getYears();
        }
    }
}
