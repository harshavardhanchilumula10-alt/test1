package com.employeeinsurancemanagement.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EnrollmentFormdto {
    private Long employeeId;
    private Long policyId;
    private String nomineeName;
    private String nomineeRelationship;
    private Double estimatedPremium;

    private List<DependentDTO> dependents = new java.util.ArrayList<>();
}
