package com.employeeinsurancemanagement.dto;

import com.employeeinsurancemanagement.model.EmployeeAddress;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * DTO for HR creating new employee.
 * All validations applied at DTO level.
 */
@Getter
@Setter
@RequiredArgsConstructor
public class EmployeeCreateRequest {

    @NotBlank(message = "Employee name is required")
    @Size(min = 3, max = 50, message = "Name must be 3-50 characters")
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Name can only contain letters and spaces")
    private String employeeName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    @Pattern(regexp = "^[a-zA-Z0-9._%+-]+@(cognizant|wipro|zepto)\\.com$", message = "Email must be from cognizant.com, wipro.com, or zepto.com")
    private String email;

    @NotNull(message = "Phone number is required")
    @Pattern(regexp = "^[6-9][0-9]{9}$", message = "Must be a valid 10-digit Indian mobile number")
    private String phoneNumber;

    @NotBlank(message = "Designation is required")
    @Size(max = 100, message = "Designation cannot exceed 100 characters")
    private String designation;

    @NotNull(message = "Date of birth is required")
    @com.employeeinsurancemanagement.validation.ValidAge(min = 18, max = 70, message = "Employee must be between 18 and 70 years old")
    private LocalDate dateOfBirth;

    @Valid
    @NotNull(message = "Address is required")
    private EmployeeAddress address;

    @NotNull(message = "Joining date is required")
    @PastOrPresent(message = "Joining date cannot be in the future")
    private LocalDate joiningDate;

    @NotBlank(message = "Password is required")
    @Size(min = 6, max = 20, message = "Password must be 6-20 characters")
    private String password;
}
