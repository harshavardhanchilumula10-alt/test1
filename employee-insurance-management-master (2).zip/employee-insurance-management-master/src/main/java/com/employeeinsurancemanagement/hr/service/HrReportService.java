package com.employeeinsurancemanagement.hr.service;

import com.employeeinsurancemanagement.employee.model.Employee;
import com.employeeinsurancemanagement.employee.model.EmployeeStatus;
import com.employeeinsurancemanagement.employee.repository.EmployeeRepository;
import com.employeeinsurancemanagement.enrollment.model.EnrollmentStatus;
import com.employeeinsurancemanagement.enrollment.repository.EnrollmentRepository;
import com.employeeinsurancemanagement.hr.dto.EmployeeCoverageReportDTO;
import com.employeeinsurancemanagement.hr.dto.EnrollmentStateFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service for HR reports only.
 * Does NOT modify any data - read-only operations.
 * Handles filtering, sorting, and pagination logic.
 */
@Service
@RequiredArgsConstructor
public class HrReportService {

    private final EmployeeRepository employeeRepository;
    private final EnrollmentRepository enrollmentRepository;

    // Whitelist of sortable fields
    private static final Map<String, String> SORT_FIELD_MAP = Map.of(
            "name", "employeeName",
            "joiningDate", "joiningDate",
            "status", "status",
            "category", "category");

    /**
     * Get filtered, sorted, paginated employee coverage report.
     * 
     * @param organizationId        Organization ID (from HR login)
     * @param statusFilter          Status filter (null or "ALL" = no filter)
     * @param categoryFilter        Category filter (null or "ALL" = no filter)
     * @param enrollmentStateFilter Enrollment state filter
     * @param sortBy                Sort field (whitelisted)
     * @param sortDir               Sort direction ("asc" or "desc")
     * @param page                  Page number (0-indexed)
     * @param pageSize              Page size (10/25/50)
     * @return Paginated list of DTOs
     */
    public EmployeeCoverageReportResult getEmployeeCoverageReport(
            Long organizationId,
            String statusFilter,
            String categoryFilter,
            EnrollmentStateFilter enrollmentStateFilter,
            String sortBy,
            String sortDir,
            int page,
            int pageSize) {

        // 1. Fetch all employees for organization
        List<Employee> employees = employeeRepository.findByOrganizationOrganizationId(organizationId);

        // 2. Map to DTOs with resolved category and enrollment count
        List<EmployeeCoverageReportDTO> dtos = employees.stream()
                .map(emp -> {
                    Employee.EmployeeCategory resolvedCategory = resolveCategory(emp);
                    int activeEnrollments = enrollmentRepository.countByEmployeeAndEnrollmentStatus(
                            emp, EnrollmentStatus.ACTIVE);
                    return EmployeeCoverageReportDTO.fromEmployee(emp, resolvedCategory, activeEnrollments);
                })
                .collect(Collectors.toList());

        // 3. Apply status filter
        if (statusFilter != null && !statusFilter.isEmpty() && !statusFilter.equalsIgnoreCase("ALL")) {
            try {
                EmployeeStatus status = EmployeeStatus.valueOf(statusFilter.toUpperCase());
                dtos = dtos.stream()
                        .filter(dto -> dto.getStatus() == status)
                        .collect(Collectors.toList());
            } catch (IllegalArgumentException ignored) {
                // Invalid status - ignore filter
            }
        }

        // 4. Apply category filter
        if (categoryFilter != null && !categoryFilter.isEmpty() && !categoryFilter.equalsIgnoreCase("ALL")) {
            try {
                Employee.EmployeeCategory category = Employee.EmployeeCategory.valueOf(categoryFilter.toUpperCase());
                dtos = dtos.stream()
                        .filter(dto -> dto.getCategory() == category)
                        .collect(Collectors.toList());
            } catch (IllegalArgumentException ignored) {
                // Invalid category - ignore filter
            }
        }

        // 5. Apply enrollment state filter (in-memory, NOT in repository)
        if (enrollmentStateFilter != null && enrollmentStateFilter != EnrollmentStateFilter.ALL) {
            boolean filterEnrolled = enrollmentStateFilter == EnrollmentStateFilter.ENROLLED;
            dtos = dtos.stream()
                    .filter(dto -> dto.isEnrolled() == filterEnrolled)
                    .collect(Collectors.toList());
        }

        // 6. Apply sorting (whitelisted fields only)
        Comparator<EmployeeCoverageReportDTO> comparator = getComparator(sortBy, sortDir);
        dtos.sort(comparator);

        // 7. Calculate pagination
        int totalElements = dtos.size();
        int totalPages = (int) Math.ceil((double) totalElements / pageSize);
        int fromIndex = Math.min(page * pageSize, totalElements);
        int toIndex = Math.min(fromIndex + pageSize, totalElements);

        List<EmployeeCoverageReportDTO> pageContent = dtos.subList(fromIndex, toIndex);

        return new EmployeeCoverageReportResult(
                pageContent,
                page,
                pageSize,
                totalElements,
                totalPages);
    }

    /**
     * Resolve employee category based on tenure (5+ years = SENIOR).
     * Same logic as in other services.
     */
    private Employee.EmployeeCategory resolveCategory(Employee employee) {
        if (employee.getJoiningDate() == null) {
            return Employee.EmployeeCategory.JUNIOR;
        }
        int yearsOfService = Period.between(employee.getJoiningDate(), LocalDate.now()).getYears();
        return yearsOfService >= 5 ? Employee.EmployeeCategory.SENIOR : Employee.EmployeeCategory.JUNIOR;
    }

    /**
     * Get comparator for sorting based on whitelisted field.
     * Defaults to name ascending if field is not whitelisted.
     */
    private Comparator<EmployeeCoverageReportDTO> getComparator(String sortBy, String sortDir) {
        boolean ascending = !"desc".equalsIgnoreCase(sortDir);

        // Validate sort field - default to name if not whitelisted
        String field = SORT_FIELD_MAP.getOrDefault(sortBy, "employeeName");

        Comparator<EmployeeCoverageReportDTO> comparator;

        switch (field) {
            case "joiningDate":
                comparator = Comparator.comparing(
                        EmployeeCoverageReportDTO::getJoiningDate,
                        Comparator.nullsLast(Comparator.naturalOrder()));
                break;
            case "status":
                comparator = Comparator.comparing(
                        dto -> dto.getStatus().name());
                break;
            case "category":
                comparator = Comparator.comparing(
                        dto -> dto.getCategory().name());
                break;
            case "employeeName":
            default:
                comparator = Comparator.comparing(
                        EmployeeCoverageReportDTO::getEmployeeName,
                        Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER));
                break;
        }

        return ascending ? comparator : comparator.reversed();
    }

    /**
     * Result wrapper for paginated report.
     */
    public record EmployeeCoverageReportResult(
            List<EmployeeCoverageReportDTO> content,
            int currentPage,
            int pageSize,
            int totalElements,
            int totalPages) {
        public boolean hasNext() {
            return currentPage < totalPages - 1;
        }

        public boolean hasPrevious() {
            return currentPage > 0;
        }
    }
}
