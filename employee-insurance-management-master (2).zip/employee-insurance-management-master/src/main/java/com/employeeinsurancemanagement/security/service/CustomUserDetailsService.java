package com.employeeinsurancemanagement.security.service;

import com.employeeinsurancemanagement.employee.model.Employee;
import com.employeeinsurancemanagement.employee.repository.EmployeeRepository;
import com.employeeinsurancemanagement.enrollment.model.Enrollment;
import com.employeeinsurancemanagement.enrollment.model.EnrollmentStatus;
import com.employeeinsurancemanagement.enrollment.repository.EnrollmentRepository;
import com.employeeinsurancemanagement.security.model.User;
import com.employeeinsurancemanagement.security.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final EmployeeRepository employeeRepository;
    private final EnrollmentRepository enrollmentRepository;

    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Invalid credentials"));

        if (!user.isActive()) {
            throw new RuntimeException("User is inactive");
        }

        // Policy tenure check - only for EMPLOYEE role
        if (user.getRole() == User.Role.EMPLOYEE) {
            Employee employee = employeeRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Employee record not found"));

            // Check if employee has any active enrollment with valid coverage dates
            List<Enrollment> activeEnrollments = enrollmentRepository.findByEmployee(employee)
                    .stream()
                    .filter(e -> e.getEnrollmentStatus() == EnrollmentStatus.ACTIVE)
                    .filter(e -> e.getCoverageEndDate() == null ||
                            !LocalDate.now().isAfter(e.getCoverageEndDate()))
                    .toList();

            if (activeEnrollments.isEmpty()) {
                // Check if employee ever had any enrollments
                List<Enrollment> allEnrollments = enrollmentRepository.findByEmployee(employee);
                if (!allEnrollments.isEmpty()) {
                    // Employee had enrollments but all have expired
                    throw new RuntimeException(
                            "All your policy coverages have expired. Please contact HR for renewal.");
                }
                // Employee has no enrollments yet - allow login so they can enroll
                // (only ACTIVE employees can enroll, checked at service layer)
            }
        }

        return org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail())
                .password(user.getPassword())
                .roles(user.getRole().name())
                .build();
    }
}
