package com.employeeinsurancemanagement.enrollment.model;

public enum EnrollmentStatus {
    ACTIVE, INACTIVE ,CANCELLED
}
