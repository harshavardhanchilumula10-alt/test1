package com.employeeinsurancemanagement.enrollment.model;

import com.employeeinsurancemanagement.premium.model.DependentDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class EnrollmentRequest {
    private Long employeeId;
    private Long policyId;
    private List<DependentDTO> dependents;
}
