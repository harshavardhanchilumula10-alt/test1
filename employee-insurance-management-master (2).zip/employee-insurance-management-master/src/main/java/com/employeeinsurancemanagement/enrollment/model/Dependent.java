package com.employeeinsurancemanagement.enrollment.model;

import com.employeeinsurancemanagement.employee.model.Employee;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Entity
@Getter
@Setter
public class Dependent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long dependentId;

    private String name;
    @Column(name = "relationship")
    private String relation;
    private LocalDate dateOfBirth;

    @ManyToOne(optional = false)
    @JoinColumn(name = "enrollment_id")
    private Enrollment enrollment;

    @ManyToOne(optional = false)
    @JoinColumn(name = "employee_id")
    private Employee employee;
}
