package com.employeeinsurancemanagement.premium.service;

import com.employeeinsurancemanagement.premium.model.PremiumInput;

public interface PremiumCalculator {

    double calculatePremium(PremiumInput input);
}
