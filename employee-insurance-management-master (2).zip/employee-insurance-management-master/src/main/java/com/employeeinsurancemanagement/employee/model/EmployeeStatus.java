package com.employeeinsurancemanagement.employee.model;

public enum EmployeeStatus{
    ACTIVE,NOTICE,EXITED
}