package com.employeeinsurancemanagement.claim.service;

import com.employeeinsurancemanagement.claim.model.Claim;
import java.util.List;

public interface ClaimService {
    Claim submitClaim(Long employeeId, Long enrollmentId, Double claimAmount, String claimReason);
    Claim approveClaim(Long claimId);
    Claim rejectClaim(Long claimId, String rejectionReason);
    Claim getClaimById(Long claimId);
    List<Claim> getClaimsByEmployee(Long employeeId);
    int getApprovedClaimsCountByEmployee(Long employeeId);

    // New methods for balance tracking
    double getTotalApprovedClaimAmount(Long enrollmentId);
    double getRemainingCoverage(Long enrollmentId);
    List<Claim> getAllClaims();
}