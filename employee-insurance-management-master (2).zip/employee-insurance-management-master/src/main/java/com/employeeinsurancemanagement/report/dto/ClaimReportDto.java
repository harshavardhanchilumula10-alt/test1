package com.employeeinsurancemanagement.report.dto;

import lombok.Getter;

@Getter
public class ClaimReportDto {

    private final Long enrollmentId;
    private final Long totalClaims;
    private final Double totalApprovedAmount;

    public ClaimReportDto(Long enrollmentId,
                          Long totalClaims,
                          Double totalApprovedAmount) {
        this.enrollmentId = enrollmentId;
        this.totalClaims = totalClaims;
        this.totalApprovedAmount = totalApprovedAmount;
    }
}
