package com.employeeinsurancemanagement.report.service;

import com.employeeinsurancemanagement.report.dto.*;

import java.util.List;

public interface ReportService {

    // DATA
    List<EmployeeReportDto> getEmployeeCountByOrganization(Long organizationId);

    // COMMENTED OUT: Not used anywhere in the application
    // List<EnrollmentReportDto> getEnrollmentCountByPolicy();

    List<ClaimReportDto> getClaimSummaryByEnrollment();

    List<PremiumReportDto> getPremiumCollectedByOrganization(Long organizationId);

    // EXPORTS
    byte[] exportEmployeeReportExcel();

    byte[] exportEmployeeReportPdf();
}
