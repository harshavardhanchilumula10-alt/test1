package com.employeeinsurancemanagement.report.dto;

import lombok.Getter;
@Getter
public class PremiumReportDto {

    private final Long organizationId;
    private final String organizationName;
    private final Double totalPremiumCollected;

    public PremiumReportDto(Long organizationId,
                            String organizationName,
                            Double totalPremiumCollected) {
        this.organizationId = organizationId;
        this.organizationName = organizationName;
        this.totalPremiumCollected = totalPremiumCollected;
    }
}
