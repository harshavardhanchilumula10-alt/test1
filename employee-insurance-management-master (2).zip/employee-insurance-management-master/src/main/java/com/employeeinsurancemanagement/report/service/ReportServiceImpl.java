package com.employeeinsurancemanagement.report.service;

import com.employeeinsurancemanagement.report.dto.*;
import com.employeeinsurancemanagement.report.exporter.EmployeeReportExcelExporter;
import com.employeeinsurancemanagement.report.exporter.EmployeeReportPdfExporter;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportServiceImpl implements ReportService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public List<EmployeeReportDto> getEmployeeCountByOrganization(Long organizationId) {
        String query = """
                    SELECT new com.employeeinsurancemanagement.report.dto.EmployeeReportDto(
                        o.organizationId,
                        o.organizationName,
                        COUNT(e)
                    )
                    FROM Organization o
                    LEFT JOIN o.employee e
                    WHERE (:orgId IS NULL OR o.organizationId = :orgId)
                    GROUP BY o.organizationId, o.organizationName
                """;
        return em.createQuery(query, EmployeeReportDto.class)
                .setParameter("orgId", organizationId)
                .getResultList();
    }

    // COMMENTED OUT: Not used anywhere in the application
    // @Override
    // public List<EnrollmentReportDto> getEnrollmentCountByPolicy() {
    // return em.createQuery("""
    // SELECT new com.employeeinsurancemanagement.report.dto.EnrollmentReportDto(
    // p.policyId,
    // p.policyName,
    // COUNT(e)
    // )
    // FROM Policy p
    // LEFT JOIN Enrollment e ON e.policy = p
    // GROUP BY p.policyId, p.policyName
    // """, EnrollmentReportDto.class).getResultList();
    // }

    @Override
    public List<ClaimReportDto> getClaimSummaryByEnrollment() {

        List<Object[]> rows = em.createQuery("""
                    SELECT
                        e.enrollmentId,
                        COUNT(c),
                        COALESCE(SUM(c.approvedAmount), 0)
                    FROM Enrollment e
                    LEFT JOIN Claim c
                        ON c.enrollment = e
                       AND c.claimStatus = 'APPROVED'
                    GROUP BY e.enrollmentId
                """).getResultList();

        return rows.stream()
                .map(r -> new ClaimReportDto(
                        (Long) r[0],
                        (Long) r[1],
                        ((Number) r[2]).doubleValue()))
                .toList();
    }

    @Override
    public List<PremiumReportDto> getPremiumCollectedByOrganization(Long organizationId) {

        List<Object[]> rows = em.createQuery("""
                    SELECT
                        o.organizationId,
                        o.organizationName,
                        COALESCE(SUM(e.premiumAmount), 0)
                    FROM Organization o
                    LEFT JOIN Enrollment e
                        ON e.employee.organization = o
                    WHERE (:orgId IS NULL OR o.organizationId = :orgId)
                    GROUP BY o.organizationId, o.organizationName
                """)
                .setParameter("orgId", organizationId)
                .getResultList();

        return rows.stream()
                .map(r -> new PremiumReportDto(
                        (Long) r[0],
                        (String) r[1],
                        ((Number) r[2]).doubleValue()))
                .toList();
    }

    // -------- EXPORTS --------

    @Override
    public byte[] exportEmployeeReportExcel() {
        List<EmployeeReportDto> data = getEmployeeCountByOrganization(null);
        return new EmployeeReportExcelExporter().export(data);
    }

    @Override
    public byte[] exportEmployeeReportPdf() {
        List<EmployeeReportDto> data = getEmployeeCountByOrganization(null);
        return new EmployeeReportPdfExporter().export(data);
    }
}
