package com.employeeinsurancemanagement.policy.service;

import com.employeeinsurancemanagement.employee.repository.EmployeeRepository;
import com.employeeinsurancemanagement.exception.BusinessException;
import com.employeeinsurancemanagement.exception.ResourceNotFoundException;
import com.employeeinsurancemanagement.organization.model.Organization;
import com.employeeinsurancemanagement.organization.repository.OrganizationRepository;
import com.employeeinsurancemanagement.policy.model.Policy;
import com.employeeinsurancemanagement.policy.repository.PolicyRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.employeeinsurancemanagement.enrollment.model.EnrollmentStatus;
import com.employeeinsurancemanagement.employee.model.Employee;
import com.employeeinsurancemanagement.enrollment.repository.EnrollmentRepository;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class PolicyServiceImpl implements PolicyService {

        private final PolicyRepository policyRepository;
        private final OrganizationRepository organizationRepository;
        private final EmployeeRepository employeeRepository;
        private final EnrollmentRepository enrollmentRepository;

        /**
         * Resolves employee category based on tenure.
         * If tenure >= 5 years, employee is SENIOR, otherwise JUNIOR.
         */
        private Employee.EmployeeCategory resolveCategory(Employee employee) {
                if (employee.getJoiningDate() == null) {
                        return Employee.EmployeeCategory.JUNIOR;
                }
                int years = Period.between(employee.getJoiningDate(), LocalDate.now()).getYears();
                return years >= 5 ? Employee.EmployeeCategory.SENIOR : Employee.EmployeeCategory.JUNIOR;
        }

        /**
         * Applies dynamic category resolution to an employee.
         */
        private Employee applyDynamicCategory(Employee employee) {
                employee.setEmployeeCategory(resolveCategory(employee));
                return employee;
        }

        @Override
        public Policy getPolicyById(Long policyId) {
                return policyRepository.findById(policyId)
                                .orElseThrow(() -> new ResourceNotFoundException("Policy not found"));
        }

        @Override
        public List<Policy> getPoliciesByOrganization(Long organizationId) {
                Organization org = organizationRepository.findById(organizationId)
                                .orElseThrow(() -> new BusinessException("Organization not found"));

                return policyRepository.findByOrganizationAndActiveTrue(org);
        }

        @Override
        public List<Policy> getAvailablePoliciesForEmployee(Long employeeId) {
                Employee employee = employeeRepository.findById(employeeId)
                                .orElseThrow(() -> new ResourceNotFoundException("Employee not found"));

                // Apply dynamic category based on tenure
                applyDynamicCategory(employee);

                Long orgId = employee.getOrganization().getOrganizationId();

                // Use organization ID directly for more reliable query
                List<Policy> allOrgPolicies = policyRepository.findByOrganizationOrganizationIdAndActiveTrue(orgId);

                // Filter by multi-category eligibility and exclude already enrolled policies
                return allOrgPolicies.stream()
                                .filter(policy -> {
                                        // Check multi-category eligibility
                                        boolean isEligible = false;
                                        if (employee.getEmployeeCategory() == com.employeeinsurancemanagement.employee.model.Employee.EmployeeCategory.JUNIOR
                                                        && Boolean.TRUE.equals(policy.getEligibleJunior())) {
                                                isEligible = true;
                                        }
                                        if (employee.getEmployeeCategory() == com.employeeinsurancemanagement.employee.model.Employee.EmployeeCategory.SENIOR
                                                        && Boolean.TRUE.equals(policy.getEligibleSenior())) {
                                                isEligible = true;
                                        }
                                        return isEligible;
                                })
                                .filter(policy -> !enrollmentRepository.existsByEmployeeAndPolicyAndEnrollmentStatus(
                                                employee, policy, EnrollmentStatus.ACTIVE))
                                .toList();
        }

}
