package com.employeeinsurancemanagement.policy.model;

import com.employeeinsurancemanagement.organization.model.Organization;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Policy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long policyId;

    @Column(nullable = false)
    private String policyName;

    @Enumerated(EnumType.STRING)
    private PolicyType policyType;

    @Column(nullable = false)
    private Double coverageAmount;

    private Double basePremium;

    // Multi-category eligibility flags
    @Column(name = "eligible_junior")
    private Boolean eligibleJunior;

    @Column(name = "eligible_senior")
    private Boolean eligibleSenior;

    @ManyToOne(optional = false)
    @JoinColumn(name = "organization_id")
    private Organization organization;

    @Column(nullable = false)
    private boolean active = true;

}
