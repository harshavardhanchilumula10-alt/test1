package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.model.Enrollment;
import com.employeeinsurancemanagement.model.EnrollmentRequest;

import java.util.List;

public interface EnrollmentService {

    Enrollment enroll(EnrollmentRequest request);

    double calculatePremium(EnrollmentRequest request);

    Enrollment cancel(Long enrollmentId);

    Enrollment getById(Long enrollmentId);

    List<Enrollment> getByEmployee(Long employeeId);

    List<Enrollment> getByPolicy(Long policyId);
}
