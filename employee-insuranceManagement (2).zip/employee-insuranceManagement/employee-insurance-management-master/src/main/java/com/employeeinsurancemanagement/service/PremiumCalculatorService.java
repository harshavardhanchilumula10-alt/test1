package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.model.Employee.EmployeeCategory;
import com.employeeinsurancemanagement.model.PolicyType;
import com.employeeinsurancemanagement.model.PremiumInput;
import org.springframework.stereotype.Service;

@Service
public class PremiumCalculatorService implements PremiumCalculator {

    @Override
    public double calculatePremium(PremiumInput input) {
        double premium = input.getBasePremium();

        //age risk
        if (input.getAge() < 30)
            premium += 200;
        else if (input.getAge() < 40)
            premium += 400;
        else if (input.getAge() < 50)
            premium += 700;
        else
            premium += 1200;

        //family load
        if (input.getPolicyType() == PolicyType.FAMILY) {
            premium += 1200;

            if (input.getDependents() != null) {
                premium += input.getDependents().size() * 400;
            }
        }

        //claim risk
        if (input.getPastClaimsCount() > 1) {
            premium += input.getPastClaimsCount() * 300;
        }

        //coverage slab
        double coverage = input.getCoverageAmount();
        if (coverage <= 500_000)
            premium += 500;
        else if (coverage <= 1_000_000)
            premium += 1000;
        else
            premium += 1800;

        //loyalty discount
        if (input.getTenureYears() >= 8) {
            premium -= premium * 0.10;
        }

        //senior benefit
        if (input.getCategory() == EmployeeCategory.SENIOR) {
            premium -= 300;
        }

        //hard caps
        double min = input.getBasePremium() * 0.8;
        double max = input.getBasePremium() * 1.8;

        premium = Math.max(min, Math.min(premium, max));

        return Math.round(premium);
    }
}
