package com.employeeinsurancemanagement.service;

import com.employeeinsurancemanagement.dto.PremiumReportDto;
import com.employeeinsurancemanagement.exception.ReportGenerationException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class PremiumReportExcelExporter {

    public byte[] export(List<PremiumReportDto> data) {
        try (Workbook workbook = new XSSFWorkbook();
                ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Premium Report");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Organization ID");
            header.createCell(1).setCellValue("Organization Name");
            header.createCell(2).setCellValue("Total Premium Collected");

            int rowIdx = 1;
            for (PremiumReportDto dto : data) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(dto.getOrganizationId());
                row.createCell(1).setCellValue(dto.getOrganizationName());
                row.createCell(2).setCellValue(dto.getTotalPremiumCollected());
            }

            workbook.write(out);
            return out.toByteArray();
        } catch (Exception e) {
            throw new ReportGenerationException("Excel generation failed", e);
        }
    }
}
