package com.employeeinsurancemanagement.dto;

import java.time.LocalDate;
import lombok.Getter;

@Getter
public class ClaimReportDto {

    private final Long enrollmentId;
    private final Long claimId;
    private final Double approvedAmount;
    private final LocalDate claimDate;
    private final String claimStatus;

    public ClaimReportDto(Long enrollmentId,
            Long claimId,
            Double approvedAmount,
            LocalDate claimDate,
            com.employeeinsurancemanagement.model.ClaimStatus claimStatus) {
        this.enrollmentId = enrollmentId;
        this.claimId = claimId;
        this.approvedAmount = approvedAmount;
        this.claimDate = claimDate;
        this.claimStatus = (claimStatus != null) ? claimStatus.name() : "N/A";
    }
}
