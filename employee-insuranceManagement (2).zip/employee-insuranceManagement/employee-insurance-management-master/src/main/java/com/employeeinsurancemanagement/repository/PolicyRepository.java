package com.employeeinsurancemanagement.repository;

import com.employeeinsurancemanagement.model.Organization;
import com.employeeinsurancemanagement.model.Policy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {
    List<Policy> findByOrganization(Organization organization);

    List<Policy> findByOrganizationAndActiveTrue(Organization organization);

    // Query by organization ID directly for more reliable matching
    List<Policy> findByOrganizationOrganizationIdAndActiveTrue(Long organizationId);
}
