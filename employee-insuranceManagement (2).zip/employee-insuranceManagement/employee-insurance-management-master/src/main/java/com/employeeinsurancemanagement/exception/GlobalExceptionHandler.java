package com.employeeinsurancemanagement.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.NoSuchElementException;
import java.util.stream.Collectors;

/**
 * Global exception handler for MVC controllers.
 * Catches all application-level exceptions and redirects with flash attributes
 * for UI display.
 * 
 * Note: HTTP-level errors (404, 403, 500) are handled by ErrorPageController.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * Handles BusinessException - validation/business rule violations.
     * Redirects back to the referer page with the error message.
     */
    @ExceptionHandler(BusinessException.class)
    public String handleBusinessException(BusinessException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.warn("Business exception: {}", ex.getMessage());
        redirectAttributes.addFlashAttribute("error", ex.getMessage());

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles ResourceNotFoundException - when a requested resource is not found.
     * Redirects to dashboard with error message.
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public String handleResourceNotFound(ResourceNotFoundException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.warn("Resource not found: {}", ex.getMessage());
        redirectAttributes.addFlashAttribute("error", ex.getMessage());

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles ReportGenerationException - when PDF/Excel generation fails.
     * Redirects back with error message.
     */
    @ExceptionHandler(ReportGenerationException.class)
    public String handleReportGenerationException(ReportGenerationException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.error("Report generation failed: {}", ex.getMessage(), ex);
        redirectAttributes.addFlashAttribute("error", "Report generation failed. Please try again.");

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles MethodArgumentNotValidException - validation errors from @Valid
     * annotations.
     * Extracts field-level error messages and displays them.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public String handleValidationException(MethodArgumentNotValidException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        String errors = ex.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));

        log.warn("Validation failed: {}", errors);
        redirectAttributes.addFlashAttribute("error", "Validation failed: " + errors);

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles BindException - form binding errors.
     * Extracts field-level error messages and displays them.
     */
    @ExceptionHandler(BindException.class)
    public String handleBindException(BindException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        String errors = ex.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining(", "));

        log.warn("Binding error: {}", errors);
        redirectAttributes.addFlashAttribute("error", "Form validation failed: " + errors);

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles IllegalArgumentException - invalid method arguments.
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public String handleIllegalArgumentException(IllegalArgumentException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.warn("Illegal argument: {}", ex.getMessage());
        redirectAttributes.addFlashAttribute("error", ex.getMessage());

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles NoSuchElementException - typically from .orElseThrow() calls.
     */
    @ExceptionHandler(NoSuchElementException.class)
    public String handleNoSuchElementException(NoSuchElementException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.warn("Element not found: {}", ex.getMessage());
        redirectAttributes.addFlashAttribute("error", "The requested item was not found.");

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Handles DataIntegrityViolationException - database constraint violations.
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public String handleDataIntegrityViolation(DataIntegrityViolationException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.error("Data integrity violation: {}", ex.getMostSpecificCause().getMessage());

        // Extract meaningful message from the exception
        String message = ex.getMostSpecificCause().getMessage();
        String userMessage = "A data integrity error occurred.";

        if (message != null) {
            String lowerMessage = message.toLowerCase();
            if (lowerMessage.contains("duplicate") || lowerMessage.contains("unique")) {
                // Try to extract the field name from the error message
                String fieldName = extractFieldName(lowerMessage);
                if (fieldName != null) {
                    userMessage = "A record with this " + fieldName + " already exists. Please use a different value.";
                } else {
                    userMessage = "A record with this value already exists. Please use a different value.";
                }
            } else if (lowerMessage.contains("foreign key") || lowerMessage.contains("constraint")) {
                userMessage = "Cannot complete operation due to data dependencies.";
            }
        }

        redirectAttributes.addFlashAttribute("error", userMessage);

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Extracts the field name from a database constraint violation message.
     */
    private String extractFieldName(String message) {
        // Common field patterns in constraint violation messages
        if (message.contains("email")) {
            return "email";
        } else if (message.contains("phone") || message.contains("phone_number") || message.contains("phonenumber")) {
            return "phone number";
        } else if (message.contains("username") || message.contains("user_name")) {
            return "username";
        } else if (message.contains("employee_id") || message.contains("employeeid")) {
            return "employee ID";
        } else if (message.contains("organization")) {
            return "organization";
        }
        return null;
    }

    /**
     * Handles NumberFormatException - invalid number conversion.
     */
    @ExceptionHandler(NumberFormatException.class)
    public String handleNumberFormatException(NumberFormatException ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.warn("Number format error: {}", ex.getMessage());
        redirectAttributes.addFlashAttribute("error", "Invalid number format. Please enter valid numeric values.");

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }

    /**
     * Fallback handler for any other uncaught exceptions.
     * For RuntimeExceptions, shows the actual message.
     * For other exceptions, shows a generic message to avoid exposing internal
     * details.
     */
    @ExceptionHandler(Exception.class)
    public String handleGenericException(Exception ex,
            HttpServletRequest request,
            RedirectAttributes redirectAttributes) {
        log.error("Unexpected error occurred", ex);

        String errorMessage;
        if (ex instanceof RuntimeException && ex.getMessage() != null && !ex.getMessage().isEmpty()) {
            // For RuntimeExceptions with meaningful messages, show them
            errorMessage = ex.getMessage();
        } else {
            errorMessage = "An unexpected error occurred. Please try again.";
        }

        redirectAttributes.addFlashAttribute("error", errorMessage);

        String referer = request.getHeader("Referer");
        if (referer != null && !referer.isEmpty()) {
            return "redirect:" + referer;
        }
        return "redirect:/dashboard";
    }
}
